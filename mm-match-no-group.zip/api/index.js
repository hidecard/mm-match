import { Telegraf, Markup } from 'telegraf';
import { createClient } from '@libsql/client';
import 'dotenv/config';

// Check environment variables
if (!process.env.BOT_TOKEN) console.error('BOT_TOKEN is missing');
if (!process.env.TURSO_URL) console.error('TURSO_URL is missing');
if (!process.env.TURSO_TOKEN) console.error('TURSO_TOKEN is missing');

const bot = new Telegraf(process.env.BOT_TOKEN);
let db;

// In-memory session cache for viewed profile IDs (userId -> Set of profileIds)
// Note: This is per-instance cache, works best for warm serverless functions
const sessionViewedCache = new Map();

// Live stats tracking - Queries real database data
const stats = {
    // In-memory for quick match tracking
    todayMatches: 0,
    lastMatchDate: new Date().toDateString(),
    cachedTotalUsers: 0,
    lastCacheTime: 0,
    
    addMatch() {
        const today = new Date().toDateString();
        if (this.lastMatchDate !== today) {
            this.todayMatches = 0;
            this.lastMatchDate = today;
        }
        this.todayMatches++;
    },
    
    // Get real stats from database
    async getRealStats() {
        if (!db) return { online: 0, matches: 0, total: 0 };
        
        try {
            // Get total registered users (always fresh data)
            const totalResult = await db.execute({
                sql: "SELECT COUNT(*) as count FROM users WHERE is_registered = 1",
                args: []
            });
            const totalUsers = totalResult.rows[0]?.count || 0;
            
            // Get total mutual matches (all time)
            const matchesResult = await db.execute({
                sql: "SELECT COUNT(*) as count FROM likes l WHERE EXISTS (SELECT 1 FROM likes l2 WHERE l2.from_user = l.to_user AND l2.to_user = l.from_user)",
                args: []
            });
            const totalMatches = Math.floor((matchesResult.rows[0]?.count || 0) / 2);
            
            console.log('Real stats - Users:', totalUsers, 'Matches:', totalMatches);
            
            return {
                online: totalUsers,  // Total registered users
                matches: totalMatches, // Total mutual matches
                total: totalUsers
            };
        } catch (error) {
            console.error('Error getting real stats:', error);
            return {
                online: 0,
                matches: 0,
                total: 0
            };
        }
    },
    
    // Legacy sync method for compatibility
    getStats() {
        const today = new Date().toDateString();
        if (this.lastMatchDate !== today) {
            this.todayMatches = 0;
            this.lastMatchDate = today;
        }
        return {
            online: this.cachedTotalUsers,
            matches: this.todayMatches
        };
    }
};

// Helper to add viewed ID to session cache
const addToSessionViewed = (userId, profileId) => {
    if (!sessionViewedCache.has(userId)) {
        sessionViewedCache.set(userId, new Set());
    }
    sessionViewedCache.get(userId).add(profileId);
    // Limit cache size per user to prevent memory issues
    if (sessionViewedCache.get(userId).size > 50) {
        const entries = Array.from(sessionViewedCache.get(userId));
        sessionViewedCache.set(userId, new Set(entries.slice(-30)));
    }
};

// Helper to get session viewed IDs as array
const getSessionViewed = (userId) => {
    return sessionViewedCache.has(userId) ? Array.from(sessionViewedCache.get(userId)) : [];
};

try {
    db = createClient({ url: process.env.TURSO_URL, authToken: process.env.TURSO_TOKEN });
} catch (error) {
    console.error('Database connection error:', error);
}

const migrateLocationSchema = async () => {
    if (!db) return;

    const migrations = [
        { sql: 'ALTER TABLE users ADD COLUMN latitude REAL', name: 'latitude' },
        { sql: 'ALTER TABLE users ADD COLUMN longitude REAL', name: 'longitude' },
        { sql: 'ALTER TABLE users ADD COLUMN interests TEXT', name: 'interests' }
    ];

    for (const migration of migrations) {
        try {
            await db.execute({ sql: migration.sql });
            console.log(`Migrated users table: added ${migration.name} column`);
        } catch (error) {
            if (!/duplicate column|already exists/i.test(error.message)) {
                console.error(`Location schema migration error (${migration.name}):`, error);
            }
        }
    }

    try {
        await db.execute({ sql: 'CREATE INDEX IF NOT EXISTS idx_location ON users(latitude, longitude) WHERE is_registered = 1' });
    } catch (error) {
        console.error('Location index migration error:', error);
    }

    try {
        await db.execute({ sql: 'CREATE INDEX IF NOT EXISTS idx_interests ON users(interests)' });
    } catch (error) {
        console.error('Location index migration error:', error);
    }
};

migrateLocationSchema().catch((error) => console.error('Location schema migration failed:', error));

const migrateAnalyticsSchema = async () => {
    if (!db) return;

    // Create user_sessions table
    try {
        await db.execute({
            sql: `CREATE TABLE IF NOT EXISTS user_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                session_date DATE NOT NULL,
                first_activity_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_activity_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                activities_count INTEGER DEFAULT 1,
                FOREIGN KEY(user_id) REFERENCES users(telegram_id)
            )`
        });
        console.log('Created user_sessions table');
    } catch (error) {
        console.error('User sessions table creation error:', error);
    }

    // Add created_at column to likes table
    try {
        await db.execute({ sql: 'ALTER TABLE likes ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP' });
        console.log('Migrated likes table: added created_at column');
    } catch (error) {
        if (!/duplicate column|already exists/i.test(error.message)) {
            console.error('Likes schema migration error:', error);
        }
    }

    // Create indexes for analytics queries
    const indexes = [
        'CREATE INDEX IF NOT EXISTS idx_user_sessions_user_date ON user_sessions(user_id, session_date)',
        'CREATE INDEX IF NOT EXISTS idx_user_sessions_date ON user_sessions(session_date)',
        'CREATE INDEX IF NOT EXISTS idx_likes_created_at ON likes(created_at)',
        'CREATE INDEX IF NOT EXISTS idx_likes_from_created ON likes(from_user, created_at)',
        'CREATE INDEX IF NOT EXISTS idx_profile_views_date ON profile_views(viewed_at)'
    ];

    for (const indexSql of indexes) {
        try {
            await db.execute({ sql: indexSql });
        } catch (error) {
            console.error('Index creation error:', error);
        }
    }

    console.log('Analytics schema migration completed');
};

migrateAnalyticsSchema().catch((error) => console.error('Analytics schema migration failed:', error));





// --- Helper Functions ---
const getUser = async (id) => {
    try {
        if (!db) return null;
        const result = await db.execute({ sql: "SELECT * FROM users WHERE telegram_id = ?", args: [id] });
        return result.rows[0];
    } catch (error) {
        console.error('Error in getUser:', error);
        return null;
    }
};

// Track user session for analytics
const trackUserSession = async (userId) => {
    try {
        if (!db) return;
        const today = new Date().toISOString().split('T')[0];
        
        // Check if session exists for today
        const existingSession = await db.execute({
            sql: "SELECT * FROM user_sessions WHERE user_id = ? AND session_date = ?",
            args: [userId, today]
        });
        
        if (existingSession.rows.length > 0) {
            // Update existing session
            await db.execute({
                sql: "UPDATE user_sessions SET last_activity_at = CURRENT_TIMESTAMP, activities_count = activities_count + 1 WHERE user_id = ? AND session_date = ?",
                args: [userId, today]
            });
        } else {
            // Create new session
            await db.execute({
                sql: "INSERT INTO user_sessions (user_id, session_date, first_activity_at, last_activity_at, activities_count) VALUES (?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 1)",
                args: [userId, today]
            });
        }
    } catch (error) {
        console.error('Error tracking user session:', error);
    }
};

// --- Discovery & Actions ---
bot.command('deleteaccount', async (ctx) => {
    try {
        const user = await getUser(ctx.from.id);
        if (!user || !user.is_registered) {
            return await ctx.reply("Profile မတွေ့ပါ။ /start နှိပ်ပြီး မှတ်ပုံတင်ပါ။");
        }
        
        await ctx.reply("⚠️ *Account ဖျက်မည်မှာ သေချာပါသလား?*\n\nသင့် Profile နဲ့ အချက်အလက်အားလုံး ပျောက်ပျက်သွားမှာဖြစ်ပါတယ်။", {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
                [Markup.button.callback('❌ ဖျက်မည်', 'delete_confirm')],
                [Markup.button.callback('ပယ်ဖျက်မည်', 'delete_cancel')]
            ])
        });
    } catch (error) {
        console.error('Delete account command error:', error);
        await ctx.reply("စနစ်အမှားဖြစ်ပါတယ်။ နောက်မှ ပြန်စမ်းကြည့်ပါ။");
    }
});

bot.action('delete_confirm', async (ctx) => {
    try {
        await ctx.answerCbQuery().catch(() => {});
        
        // Delete user data from all tables
        await db.execute({ sql: "DELETE FROM chat_sessions WHERE user_id = ?", args: [ctx.from.id] });
        await db.execute({ sql: "DELETE FROM chat_sessions WHERE matched_user_id = ?", args: [ctx.from.id] });
        await db.execute({ sql: "DELETE FROM likes WHERE from_user = ? OR to_user = ?", args: [ctx.from.id, ctx.from.id] });
        await db.execute({ sql: "DELETE FROM profile_views WHERE user_id = ? OR viewed_profile_id = ?", args: [ctx.from.id, ctx.from.id] });
        await db.execute({ sql: "DELETE FROM users WHERE telegram_id = ?", args: [ctx.from.id] });
        
        await ctx.reply("❌ သင့် Account ကို ဖျက်ပြီးပါပြီ။\n\nနောက်ထပ် ပါဝင်ချင်ရင် /start နှိပ်ပါ။");
    } catch (error) {
        console.error('Delete confirm error:', error);
        await ctx.reply("စနစ်အမှားဖြစ်ပါတယ်။ နောက်မှ ပြန်စမ်းကြည့်ပါ။");
    }
});

bot.action('delete_cancel', async (ctx) => {
    try {
        await ctx.answerCbQuery().catch(() => {});
        await ctx.reply("ပယ်ဖျက်လိုက်ပါတယ်။", Markup.keyboard([['🔍 ဖူးစာရှင်ရှာမည်', '💓 Pulse'], ['⚙️ Edit Profile', '👤 Profile'], ['🏷️ Interests'], ['❌ Delete Account', '/help']]).resize());
    } catch (error) {
        console.error('Delete cancel error:', error);
    }
});

bot.command('spark', async (ctx) => {
    try {
        const user = await getUser(ctx.from.id);
        if (!user || !user.is_registered) {
            return await ctx.reply("Profile ပြည့်စုံအောင် မှတ်ပုံတင်ပြီးမှ သုံးနိုင်ပါမယ်။ /start နှိပ်ပါ။");
        }
        
        // Clean up expired spark if exists
        if (user.daily_spark && user.spark_expires_at) {
            const now = new Date();
            const expiresAt = new Date(user.spark_expires_at);
            if (now >= expiresAt) {
                await db.execute({
                    sql: "UPDATE users SET daily_spark = NULL, spark_expires_at = NULL WHERE telegram_id = ?",
                    args: [ctx.from.id]
                });
            }
        }
        
        // Set user step to ask for spark
        await db.execute({
            sql: "UPDATE users SET step = 'ask_spark' WHERE telegram_id = ?",
            args: [ctx.from.id]
        });
        
        await ctx.reply("✨ *Daily Spark* တင်ပါ\n\nဒီနေ့ ဘာလုပ်ချင်လဲဆိုတဲ့ အခြေအနေကို Emoji လေးနဲ့ ရေးပေးပါ။\n\nဥပမာ: ဒီနေ့ညနေ လှည်းတန်းဘက် ကော်ဖီတူတူသောက်မယ့်သူရှာနေပါတယ် ☕⛈️\n\n(၂၄ နာရီအတွင်း အလိုအလျောက် ပျောက်ပျက်သွားမှာဖြစ်ပါတယ်)", { parse_mode: 'Markdown' });
    } catch (error) {
        console.error('Spark command error:', error);
        await ctx.reply("စနစ်အမှားဖြစ်ပါတယ်။ နောက်မှ ပြန်စမ်းကြည့်ပါ။");
    }
});

bot.command('test', async (ctx) => {
    await ctx.reply('Bot is working! Buttons test:', 
        Markup.inlineKeyboard([
            [Markup.button.callback('❤️ Test Like', 'test_like')],
            [Markup.button.callback('➡️ Test Next', 'test_next')]
        ])
    );
});

// Interests command - let user set interests/tags
bot.command('interests', async (ctx) => {
    try {
        const user = await getUser(ctx.from.id);
        if (!user || !user.is_registered) return await ctx.reply('Profile မရှိသေးပါ။ /start နှိပ်ပြီး မှတ်ပုံတင်ပါ။');
        await db.execute({ sql: "UPDATE users SET step = 'ask_interests' WHERE telegram_id = ?", args: [ctx.from.id] });
        await ctx.reply('သင့်စိတ်ဝင်စားသော အရာများ (tags) ကို ကော်မား သို့မဟုတ် စာလုံးဖြင့် ခွဲ၍ ရိုက်ထည့်ပေးပါ။ ဥပမာ: travel, music, food');
    } catch (error) {
        console.error('Interests command error:', error);
        await ctx.reply('စနစ်အမှားဖြစ်ပါတယ်။ နောက်မှ ပြန်စမ်းပါ။');
    }
});

bot.action('test_like', async (ctx) => {
    await ctx.answerCbQuery('Like button works!');
    await ctx.reply('✅ Like button is working!');
});

bot.action('test_next', async (ctx) => {
    await ctx.answerCbQuery('Next button works!');
    await ctx.reply('✅ Next button is working!');
});

bot.command('pulse', async (ctx) => {
    const { online, matches } = await stats.getRealStats();
    const pulseText = `💓 *Matching Pulse*\n\n` +
        `👥 စုစုပေါင်း Register လုပ်ထားသူ: *${online}* ယောက်\n` +
        `❤️ ဒီနေ့ Match အရေအတွက်: *${matches}* စုံ\n\n` +
        `🔥 MM Cupid မှာ သင့်ဖူးစာရှင်ကို ရှာဖွေလိုက်ပါ!`;
    await ctx.reply(pulseText, { parse_mode: 'Markdown' });
});

bot.command('find', async (ctx) => {
    await showNextProfile(ctx);
});

bot.command('nearby', async (ctx) => {
    const user = await getUser(ctx.from.id);
    if (!user || !user.is_registered) {
        return await ctx.reply("Profile ပြည့်စုံအောင် မှတ်ပုံတင်ပြီးမှ ရှာဖို့လို့ပါ။");
    }

    if (user.latitude == null || user.longitude == null) {
        return await ctx.reply("📍 သင့်လက်ရှိ Location မရှာရရှိသေးပါ။\n\nယခုလက်ရှိနေရာကို စနစ်တကျ Share လုပ်ပါ။", Markup.keyboard([Markup.button.locationRequest('📍 Share My Current Location')]).resize());
    }

    return await showNextProfile(ctx);
});

bot.command('edit', async (ctx) => {
    await db.execute({ sql: "UPDATE users SET step = 'edit_menu' WHERE telegram_id = ?", args: [ctx.from.id] });
    await ctx.reply("ဘာကိုပြင်ဆင်ချင်ပါသလဲ။", Markup.keyboard([['📝 Nickname', '🎂 Age'], ['🏠 Address', '📷 Photo'], ['📄 Bio', '🏷️ Interests'], ['❌ Cancel']]).resize());
});
bot.command('profile', async (ctx) => await showMyProfile(ctx));
bot.command('help', async (ctx) => {
    const helpText = `📋 **MM Cupid Bot Commands**

🔹 /start - Register your profile
🔹 /find - Find matches (🔍 ဖူးစာရှင်ရှာမည်)
🔹 /nearby - Find nearby matches using your shared location
🔹 /pulse - Live stats (💓 Pulse)
🔹 /profile - View your profile (👤 Profile)
🔹 /edit - Edit your profile (⚙️ Edit Profile)
🔹 /help - Show this help message

💕 ဖူးစာရှင်ကို ရှာဖွေလိုက်ပါ!`;
    await ctx.reply(helpText, { parse_mode: 'Markdown' });
});
bot.command('update', async (ctx) => {
    await db.execute({ sql: "UPDATE users SET step = 'ask_gender' WHERE telegram_id = ?", args: [ctx.from.id] });
    await ctx.reply("သင့်လိင်ကို ရွေးပါ (Male သို့မဟုတ် Female):", Markup.keyboard([['Male', 'Female']]).resize());
});

bot.command('cancel', async (ctx) => {
    await db.execute({ sql: "UPDATE users SET step = 'done' WHERE telegram_id = ?", args: [ctx.from.id] });
    await ctx.reply("ပယ်ဖျက်လိုက်ပါတယ်။", Markup.keyboard([['🔍 ဖူးစာရှင်ရှာမည်', '💓 Pulse'], ['⚙️ Edit Profile', '👤 Profile'], ['🏷️ Interests'], ['❌ Delete Account', '/help']]).resize());
});

// Admin commands for ban management
const ADMIN_IDS = process.env.ADMIN_IDS ? process.env.ADMIN_IDS.split(',').map(id => parseInt(id.trim())) : [];

bot.command('ban', async (ctx) => {
    const adminId = ctx.from.id;
    if (!ADMIN_IDS.includes(adminId)) {
        return await ctx.reply("❌ Admin only command");
    }
    
    const args = ctx.message.text.split(' ');
    if (args.length < 2) {
        return await ctx.reply("Usage: /ban <user_id> [reason]");
    }
    
    const userId = parseInt(args[1]);
    const reason = args.slice(2).join(' ') || 'Violation of terms';
    
    await db.execute({
        sql: "UPDATE users SET is_banned = 1, is_shadowbanned = 0, ban_reason = ?, banned_at = CURRENT_TIMESTAMP, banned_by = ? WHERE telegram_id = ?",
        args: [reason, adminId, userId]
    });
    
    await ctx.reply(`✅ User ${userId} has been banned.\nReason: ${reason}`);
});

bot.command('unban', async (ctx) => {
    const adminId = ctx.from.id;
    if (!ADMIN_IDS.includes(adminId)) {
        return await ctx.reply("❌ Admin only command");
    }
    
    const args = ctx.message.text.split(' ');
    if (args.length < 2) {
        return await ctx.reply("Usage: /unban <user_id>");
    }
    
    const userId = parseInt(args[1]);
    
    await db.execute({
        sql: "UPDATE users SET is_banned = 0, is_shadowbanned = 0, ban_reason = NULL, banned_at = NULL, banned_by = NULL WHERE telegram_id = ?",
        args: [userId]
    });
    
    await ctx.reply(`✅ User ${userId} has been unbanned.`);
});

bot.command('shadowban', async (ctx) => {
    const adminId = ctx.from.id;
    if (!ADMIN_IDS.includes(adminId)) {
        return await ctx.reply("❌ Admin only command");
    }
    
    const args = ctx.message.text.split(' ');
    if (args.length < 2) {
        return await ctx.reply("Usage: /shadowban <user_id> [reason]");
    }
    
    const userId = parseInt(args[1]);
    const reason = args.slice(2).join(' ') || 'Shadowban';
    
    await db.execute({
        sql: "UPDATE users SET is_banned = 0, is_shadowbanned = 1, ban_reason = ?, banned_at = CURRENT_TIMESTAMP, banned_by = ? WHERE telegram_id = ?",
        args: [reason, adminId, userId]
    });
    
    await ctx.reply(`✅ User ${userId} has been shadowbanned.\nReason: ${reason}`);
});

bot.command('unshadowban', async (ctx) => {
    const adminId = ctx.from.id;
    if (!ADMIN_IDS.includes(adminId)) {
        return await ctx.reply("❌ Admin only command");
    }
    
    const args = ctx.message.text.split(' ');
    if (args.length < 2) {
        return await ctx.reply("Usage: /unshadowban <user_id>");
    }
    
    const userId = parseInt(args[1]);
    
    await db.execute({
        sql: "UPDATE users SET is_shadowbanned = 0, ban_reason = NULL, banned_at = NULL, banned_by = NULL WHERE telegram_id = ?",
        args: [userId]
    });
    
    await ctx.reply(`✅ User ${userId} has been unshadowbanned.`);
});

async function showMyProfile(ctx) {
    try {
        const user = await getUser(ctx.from.id);
        if (!user) return await ctx.reply("Profile မတွေ့ပါ။ /start နှိပ်ပြီး မှတ်ပုံတင်ပါ။");
        
        // Check if spark is still valid (not expired)
        let sparkText = '';
        if (user.daily_spark && user.spark_expires_at) {
            const now = new Date();
            const expiresAt = new Date(user.spark_expires_at);
            if (now < expiresAt) {
                sparkText = `✨ ${user.daily_spark}\n\n`;
            } else {
                // Spark has expired, delete it from database
                await db.execute({
                    sql: "UPDATE users SET daily_spark = NULL, spark_expires_at = NULL WHERE telegram_id = ?",
                    args: [ctx.from.id]
                });
            }
        }
        
        const displayAddress = (user.latitude != null && user.longitude != null && (!user.address || /^(Location shared|Location updated)$/i.test(user.address.trim())))
            ? 'Location shared'
            : (user.address || 'Not set');

        const interestsLine = user.interests ? `\n🔖 ${formatInterests(user.interests)}\n` : '';

        const caption = `${sparkText}👤 **My Profile**\n\n📝 ${user.nickname} (${user.age})\n📍 ${displayAddress}\n🧬 ${user.gender?.toUpperCase()}\n💕 Looking for: ${user.looking_for?.toUpperCase()}${interestsLine}\n\n📝 ${user.bio}`;
        
        try {
            return await ctx.replyWithPhoto(user.photo_id, { caption: caption });
        } catch (e) {
            return await ctx.reply(caption);
        }
    } catch (error) {
        console.error('Error in showMyProfile:', error);
        return await ctx.reply("စနစ်အမှားဖြစ်ပါတယ်။");
    }
}

async function showNextProfile(ctx) {
    try {
        console.log('showNextProfile called for user:', ctx.from?.id);
        
        if (ctx.callbackQuery && ctx.callbackQuery.message) {
            try {
                await ctx.editMessageReplyMarkup();
                console.log('Cleared previous profile buttons for user:', ctx.from?.id);
            } catch (editErr) {
                console.log('Failed to clear previous profile buttons:', editErr.message);
            }
        }
        
        const user = await getUser(ctx.from.id);
        if (!user || !user.looking_for) {
            console.log('User not registered or no looking_for:', user);
            return await ctx.reply("Profile ပြည့်စုံအောင် မှတ်ပုံတင်ပြီးမှ ရှာဖို့လို့ပါ။");
        }
        
        // Get session viewed IDs and pass to getRandomProfile
        const sessionViewed = getSessionViewed(ctx.from.id);
        console.log('Session viewed IDs:', sessionViewed.length);
        
        const target = await getRandomProfile(ctx.from.id, user.looking_for, sessionViewed);
        if (!target) {
            console.log('No target found for user:', ctx.from.id);
            // Clear session cache when no profiles found
            sessionViewedCache.delete(ctx.from.id);
            const emptyText = `⏳ ခေတ္တစောင့်ဆိုင်းပေးပါဦး...

သတ်မှတ်ထားတဲ့ Radius အကွာအဝေးအတွင်းမှာ Swipe လုပ်စရာ Profile အသစ်တွေ ကုန်သွားပါပြီ။ ✨

🚀 သူငယ်ချင်းတွေကို Invite လုပ်ပြီး အသိုက်အဝန်းကို ပိုမိုကြီးထွားစေချင်ရင်:
သင့်သူငယ်ချင်းတွေဆီ ရိုးရှင်းစွာ တဆင့်မျှဝေပေးနိုင်ပါတယ်။

👥 လူပိုများလာလေလေ၊ သင့်အတွက် ဖူးစာရှင်အသစ်တွေ ပိုမိုပေါ်ထွက်လာလေလေ ဖြစ်မှာပါခင်ဗျာ! 💕`;
            return await ctx.reply(emptyText, { parse_mode: 'Markdown' });
        }
        
        console.log('Showing profile:', target.telegram_id, 'to user:', ctx.from.id);
        
        // Add to session cache (temporary, clears when user restarts)
        addToSessionViewed(ctx.from.id, target.telegram_id);
        
        // Persist to database for permanent deduplication across sessions
        await markProfileAsViewed(ctx.from.id, target.telegram_id);
        
        // Check if spark is still valid (not expired)
        let sparkText = '';
        if (target.daily_spark && target.spark_expires_at) {
            const now = new Date();
            const expiresAt = new Date(target.spark_expires_at);
            if (now < expiresAt) {
                sparkText = `✨ ${target.daily_spark}\n\n`;
            } else {
                // Spark has expired, delete it from database
                await db.execute({
                    sql: "UPDATE users SET daily_spark = NULL, spark_expires_at = NULL WHERE telegram_id = ?",
                    args: [target.telegram_id]
                });
            }
        }
        
        // Calculate and display distance if both users have location
        let distanceText = '';
        if (user.latitude != null && user.longitude != null && target.latitude != null && target.longitude != null) {
            const distance = calculateDistance(user.latitude, user.longitude, target.latitude, target.longitude);
            distanceText = `\n📏 ${distance.toFixed(1)} km ကွာဝေးသည်`;
        }
        
        const targetInterests = target.interests ? `\n🔖 ${formatInterests(target.interests)}` : '';
        const caption = `${sparkText}👤 ${target.nickname} (${target.age})\n📍 ${target.address}${distanceText}${targetInterests}\n\n📝 ${target.bio}`;
        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('❤️ Like', `like_${target.telegram_id}`),
             Markup.button.callback('💌 Like + Message', `like_with_message_${target.telegram_id}`)],
            [Markup.button.callback('➡️ Next', 'next_profile')],
            [Markup.button.callback('🚨 Report', `report_${target.telegram_id}`)]
        ]);
        
        
        // Try sending photo, fallback to text if photo fails
        try {
            console.log('Sending photo with ID:', target.photo_id?.substring(0, 20) + '...');
            return await ctx.replyWithPhoto(target.photo_id, {
                caption: caption,
                reply_markup: keyboard.reply_markup
            });
        } catch (photoError) {
            console.error('Photo send failed, sending text instead:', photoError.message);
            return await ctx.reply(caption, { reply_markup: keyboard.reply_markup });
        }
    } catch (error) {
        console.error('Error in showNextProfile:', error);
        return await ctx.reply("စနစ်အမှားဖြစ်ပါတယ်။ နောက်မှ ပြန်စမ်းကြည့်ပါ။");
    }
}

// Bot-level error handler
bot.catch((err, ctx) => {
    console.error('Bot error:', err);
    console.error('Context:', ctx.updateType);
});

// Action handlers
bot.action('next_profile', async (ctx) => {
    console.log('Next button clicked by:', ctx.from?.id);
    try {
        await ctx.answerCbQuery('⏳ Loading...').catch((e) => console.log('Answer error:', e.message));
        return await showNextProfile(ctx);
    } catch (error) {
        console.error('Next profile action error:', error);
        await ctx.answerCbQuery('Error!').catch(() => {});
        return await ctx.reply("စနစ်အမှားဖြစ်ပါတယ်။ နောက်မှ ပြန်စမ်းကြည့်ပါ။").catch(() => {});
    }
});

// Store pending secret messages before like is confirmed
const pendingSecretMessages = new Map();

bot.action(/^like_with_message_(.+)$/, async (ctx) => {
    const targetId = ctx.match[1];
    const senderId = ctx.from.id;
    
    console.log('Like with message clicked - sender:', senderId, 'target:', targetId);
    
    // Set user step to waiting for secret message
    await db.execute({ 
        sql: "UPDATE users SET step = ? WHERE telegram_id = ?", 
        args: [`secret_message_${targetId}`, senderId] 
    });
    
    await ctx.answerCbQuery('💌 Message');
    
    await ctx.reply(`💌 *စိတ်ကူးလေးရေးပါ*

သင့်စိတ်ကူးကို သုံးပြီး Like လုပ်ချင်ပါတယ်။
စိတ်ကူးတစ်ကြောင်းရေးပြီး ပို့လိုက်ပါ။

*ဥပမာ:* "You look cute 😊"`, { 
        parse_mode: 'Markdown',
        ...Markup.forceReply()
    });
});

bot.action(/^like_(.+)$/, async (ctx) => {
    const targetId = ctx.match[1];
    const senderId = ctx.from.id;
    const secretMessage = pendingSecretMessages.get(`${senderId}_${targetId}`);
    
    console.log('Like button clicked - sender:', senderId, 'target:', targetId, 'hasMessage:', !!secretMessage);
    
    // Clear pending message
    pendingSecretMessages.delete(`${senderId}_${targetId}`);
    
    // Validate inputs
    if (!targetId || !senderId) {
        console.error('Missing targetId or senderId');
        await ctx.answerCbQuery('အမှား!').catch(() => {});
        return;
    }
    
    if (!db) {
        console.error('Database not connected');
        await ctx.answerCbQuery('Database error').catch(() => {});
        return await ctx.reply("Database မချိတ်ဆက်နိုင်ပါ။").catch(() => {});
    }
    
    try {
        // Track user session for analytics
        await trackUserSession(senderId);
        
        // Answer callback query
        await ctx.answerCbQuery(secretMessage ? '❤️ Like + Message!' : '❤️ Like!').catch((e) => console.log('Answer error:', e.message));
        
        // Record the like and wait for it to complete
        console.log('Recording like...');
        await db.execute({ 
            sql: "INSERT OR IGNORE INTO likes (from_user, to_user, created_at) VALUES (?, ?, CURRENT_TIMESTAMP)", 
            args: [senderId, targetId] 
        });
        console.log('Like recorded successfully');
        
        // Store secret message if provided
        if (secretMessage) {
            await db.execute({
                sql: "CREATE TABLE IF NOT EXISTS secret_messages (id INTEGER PRIMARY KEY AUTOINCREMENT, from_user INTEGER, to_user INTEGER, message TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)",
                args: []
            });
            await db.execute({
                sql: "INSERT INTO secret_messages (from_user, to_user, message) VALUES (?, ?, ?)",
                args: [senderId, targetId, secretMessage]
            });
            console.log('Secret message stored');
        }
        
        // Check for mutual like
        const mutualLike = await db.execute({
            sql: "SELECT * FROM likes WHERE from_user = ? AND to_user = ?",
            args: [targetId, senderId]
        });
        console.log('Mutual like check:', mutualLike.rows.length > 0 ? 'Match!' : 'No match yet');

        if (mutualLike.rows.length > 0) {
            const me = await getUser(senderId);
            const partner = await getUser(targetId);
            
            // Get any secret messages from partner
            const partnerMsgResult = await db.execute({
                sql: "SELECT message FROM secret_messages WHERE from_user = ? AND to_user = ? ORDER BY created_at DESC LIMIT 1",
                args: [targetId, senderId]
            });
            const partnerMessage = partnerMsgResult.rows[0]?.message;
            
            if (me && partner) {
                // Insert into matches table (ensure user_one < user_two for consistency)
                const userOne = Math.min(senderId, targetId);
                const userTwo = Math.max(senderId, targetId);
                
                try {
                    await db.execute({
                        sql: "INSERT OR IGNORE INTO matches (user_one, user_two) VALUES (?, ?)",
                        args: [userOne, userTwo]
                    });
                    console.log('Match inserted into matches table');
                } catch (e) {
                    console.error('Error inserting match:', e);
                }
                
                const partnerLink = partner.username !== 'none' ? `@${partner.username}` : `tg://user?id=${targetId}`;
                const myLink = me.username !== 'none' ? `@${me.username}` : `tg://user?id=${senderId}`;
                
                let matchText = `🎉 *Match ဖြစ်သွားပါပြီ!* ❤️

👤 *${partner.nickname}* နဲ့ သင်နဲ့ စိတ်ချင်းတူသွားပါပြီ။
မိမိရဲ့ Telegram ID အစစ်အမှန်ကို မသိစေဘဲ ဘော့ခ်ျထဲမှာပဲ လုံခြုံစွာ အရင်ဆုံး စကားပြောကြည့်လိုက်ပါ!`;
                
                if (partnerMessage) {
                    matchText += `\n\n💌 *သူ့ရဲ့စိတ်ကူးလေး:* "${partnerMessage}"`;
                }
                
                if (secretMessage) {
                    matchText += `\n\n💌 *သင်ပို့တဲ့စိတ်ကူးလေး:* "${secretMessage}"`;
                }
                
                stats.addMatch();
                await ctx.reply(matchText, {
                    parse_mode: 'Markdown',
                    ...Markup.inlineKeyboard([
                        [Markup.button.callback('💬 စကားပြောမည်', `chat_${targetId}`)],
                        [Markup.button.callback('➡️ ဆက်ရှာမည်', 'next_profile')]
                    ])
                });
                
                try {
                    let partnerMatchText = `🎉 *Match ဖြစ်သွားပါပြီ!* ❤️

👤 *${me.nickname}* နဲ့ သင်နဲ့ စိတ်ချင်းတူသွားပါပြီ။
မိမိရဲ့ Telegram ID အစစ်အမှန်ကို မသိစေဘဲ ဘော့ခ်ျထဲမှာပဲ လုံခြုံစွာ အရင်ဆုံး စကားပြောကြည့်လိုက်ပါ!`;
                    
                    if (secretMessage) {
                        partnerMatchText += `\n\n💌 *သူ့ရဲ့စိတ်ကူးလေး:* "${secretMessage}"`;
                    }
                    
                    if (partnerMessage) {
                        partnerMatchText += `\n\n💌 *သင်ပို့တဲ့စိတ်ကူးလေး:* "${partnerMessage}"`;
                    }
                    
                    await bot.telegram.sendMessage(targetId, partnerMatchText, {
                        parse_mode: 'Markdown',
                        ...Markup.inlineKeyboard([
                            [Markup.button.callback('💬 စကားပြောမည်', `chat_${senderId}`)],
                            [Markup.button.callback('➡️ ဆက်ရှာမည်', 'next_profile')]
                        ])
                    });
                } catch (e) {
                    console.error('Error sending partner match notification:', e);
                }
            }
        } else {
            try {
                // Check if target user exists and is not banned
                const targetUser = await getUser(targetId);
                if (!targetUser) {
                    console.log('Target user not found for notification:', targetId);
                } else if (targetUser.is_banned || targetUser.is_shadowbanned) {
                    console.log('Target user is banned/shadowbanned, skipping notification:', targetId);
                } else {
                    const me = await getUser(senderId);
                    if (me) {
                        let likeNotifyText = `🔔 *သတင်းကောင်းရှိပါတယ်။*\n\nသင့်ကို သဘောကျလို့ Like လုပ်ထားပါတယ်။ 😉`;
                        
                        if (secretMessage) {
                            // Escape special characters for Markdown if needed, but the current app seems to use raw
                            likeNotifyText += `\n\n💌 *သူ့ရဲ့စိတ်ကူးလေး:* "${secretMessage}"`;
                        }
                        
                        likeNotifyText += `\n\nအဲဒီလူက ဘယ်သူဖြစ်မလဲဆိုတာ သိချင်ရင် အောက်က ခလုတ်ကိုနှိပ်လိုက်ပါ!`;
                        
                        console.log('Sending like notification to:', targetId);
                        await bot.telegram.sendMessage(targetId, likeNotifyText, {
                            parse_mode: 'Markdown',
                            ...Markup.inlineKeyboard([
                                [Markup.button.callback('👀 သူ့ကို ကြည့်မယ်', `view_back_${senderId}`)]
                            ])
                        }).catch(err => {
                            console.error(`Failed to send message to ${targetId}:`, err.message);
                            // If it's a "bot was blocked by the user" error, we can't do much
                        });
                        console.log('Like notification process completed');
                    }
                }
            } catch (e) {
                console.error('Error in like notification block:', e);
            }
        }
    } catch (error) {
        console.error('Like Error:', error);
        await ctx.answerCbQuery('အမှား!').catch(() => {});
    }
    
    // Always show next profile after processing the like
    console.log('Showing next profile...');
    return await showNextProfile(ctx);
});

bot.action(/^reveal_accept_(.+)$/, async (ctx) => {
    const requesterId = ctx.match[1];
    const userId = ctx.from.id;
    
    try {
        await ctx.answerCbQuery('👍 သဘောတူသည်').catch((e) => console.log('Answer error:', e.message));
        
        const requester = await getUser(requesterId);
        const me = await getUser(userId);
        
        if (requester && me) {
            // Update match to revealed
            const userOne = Math.min(userId, requesterId);
            const userTwo = Math.max(userId, requesterId);
            
            await db.execute({
                sql: "UPDATE matches SET is_revealed = 1 WHERE user_one = ? AND user_two = ?",
                args: [userOne, userTwo]
            });
            
            // Send usernames to both users
            const requesterLink = requester.username !== 'none' ? `@${requester.username}` : `tg://user?id=${requesterId}`;
            const myLink = me.username !== 'none' ? `@${me.username}` : `tg://user?id=${userId}`;
            
            await ctx.reply(`🔓 *လျှို့ဝှက်ချက်ဖွင့်ပြီးပါပြီ!*

သင့်ရဲ့ Telegram: ${myLink}
သူ့ရဲ့ Telegram: ${requesterLink}`, { parse_mode: 'Markdown' });
            
            await bot.telegram.sendMessage(requesterId, 
                `🔓 *လျှို့ဝှက်ချက်ဖွင့်ပြီးပါပြီ!*

သင့်ရဲ့ Telegram: ${requesterLink}
သူ့ရဲ့ Telegram: ${myLink}`, { parse_mode: 'Markdown' });
        }
    } catch (error) {
        console.error('Reveal accept error:', error);
    }
});

bot.action(/^reveal_reject_(.+)$/, async (ctx) => {
    const requesterId = ctx.match[1];
    
    try {
        await ctx.answerCbQuery('👎 ငြင်းပယ်မည်').catch((e) => console.log('Answer error:', e.message));
        
        await ctx.reply('👎 လျှို့ဝှက်ချက်ဖွင့်ခြင်းကို ငြင်းပယ်လိုက်ပါပြီ။ ဆက်လက် အမည်ဝှက်ဖြင့် စကားပြောနိုင်ပါသည်။');
        
        await bot.telegram.sendMessage(requesterId, '👎 သူ့ဘက်က လျှို့ဝှက်ချက်ဖွင့်ခြင်းကို ငြင်းပယ်လိုက်ပါပြီ။ ဆက်လက် အမည်ဝှက်ဖြင့် စကားပြောနိုင်ပါသည်။');
    } catch (error) {
        console.error('Reveal reject error:', error);
    }
});

bot.action(/^chat_(.+)$/, async (ctx) => {
    const matchedUserId = ctx.match[1];
    const userId = ctx.from.id;
    
    console.log('Chat button clicked - user:', userId, 'matched with:', matchedUserId);
    
    try {
        await ctx.answerCbQuery('💬 စကားပြောမည်').catch((e) => console.log('Answer error:', e.message));
        
        // Get the match ID
        const userOne = Math.min(userId, matchedUserId);
        const userTwo = Math.max(userId, matchedUserId);
        
        const matchResult = await db.execute({
            sql: "SELECT id FROM matches WHERE user_one = ? AND user_two = ?",
            args: [userOne, userTwo]
        });
        
        if (matchResult.rows.length === 0) {
            return await ctx.reply("Match မတွေ့ပါ။ ပြန်စမ်းကြည့်ပါ။");
        }
        
        const matchId = matchResult.rows[0].id;
        
        // Create chat session
        await db.execute({
            sql: "INSERT OR REPLACE INTO chat_sessions (user_id, matched_user_id, match_id) VALUES (?, ?, ?)",
            args: [userId, matchedUserId, matchId]
        });
        
        // Set user step to chat_mode
        await db.execute({
            sql: "UPDATE users SET step = 'chat_mode' WHERE telegram_id = ?",
            args: [userId]
        });
        
        // Get partner info
        const partner = await getUser(matchedUserId);
        if (!partner) {
            return await ctx.reply("Partner မတွေ့ပါ။");
        }
        
        const chatWelcomeText = `💬 *${partner.nickname}* နှင့် အမည်ဝှက် စကားပြောနေပါသည်။
(စာသား၊ ပုံ၊ အသံဖိုင်များ ပေးပို့နိုင်ပါသည်။)
--------------------------------------`;
        
        await ctx.reply(chatWelcomeText, {
            parse_mode: 'Markdown',
            ...Markup.keyboard([
                ['🔓 လျှို့ဝှက်ချက်ဖွင့်ပြမည်', '🚨 Report / Block'],
                ['🚫 Block & Unmatch', '❌ Chat မှထွက်မည်']
            ]).resize()
        });
        
    } catch (error) {
        console.error('Chat session creation error:', error);
        await ctx.reply("စနစ်အမှားဖြစ်ပါတယ်။ နောက်မှ ပြန်စမ်းကြည့်ပါ။");
    }
});

bot.action(/^report_fake_(.+)$/, async (ctx) => {
    const reportedUserId = ctx.match[1];
    const reporterId = ctx.from.id;
    
    try {
        await ctx.answerCbQuery('🚨 Report တင်ပြီးပါပြီ').catch((e) => console.log('Answer error:', e.message));
        
        await db.execute({
            sql: "INSERT INTO reports (reporter_id, reported_user_id, reason, description) VALUES (?, ?, 'fake_profile', 'Reported from anonymous chat')",
            args: [reporterId, reportedUserId]
        });
        
        await ctx.reply('🚨 Report တင်ပြီးပါပြီ။ ကျေးဇူးပါ။', Markup.keyboard([['🔍 ဖူးစာရှင်ရှာမည်', '💓 Pulse'], ['⚙️ Edit Profile', '👤 Profile'], ['🏷️ Interests'], ['❌ Delete Account', '/help']]).resize());
    } catch (error) {
        console.error('Report error:', error);
    }
});

bot.action(/^report_spam_(.+)$/, async (ctx) => {
    const reportedUserId = ctx.match[1];
    const reporterId = ctx.from.id;
    
    try {
        await ctx.answerCbQuery('🚨 Report တင်ပြီးပါပြီ').catch((e) => console.log('Answer error:', e.message));
        
        await db.execute({
            sql: "INSERT INTO reports (reporter_id, reported_user_id, reason, description) VALUES (?, ?, 'spam', 'Reported from anonymous chat')",
            args: [reporterId, reportedUserId]
        });
        
        await ctx.reply('🚨 Report တင်ပြီးပါပြီ။ ကျေးဇူးပါ။', Markup.keyboard([['🔍 ဖူးစာရှင်ရှာမည်', '💓 Pulse'], ['⚙️ Edit Profile', '👤 Profile'], ['🏷️ Interests'], ['❌ Delete Account', '/help']]).resize());
    } catch (error) {
        console.error('Report error:', error);
    }
});

bot.action(/^report_inappropriate_(.+)$/, async (ctx) => {
    const reportedUserId = ctx.match[1];
    const reporterId = ctx.from.id;
    
    try {
        await ctx.answerCbQuery('🚨 Report တင်ပြီးပါပြီ').catch((e) => console.log('Answer error:', e.message));
        
        await db.execute({
            sql: "INSERT INTO reports (reporter_id, reported_user_id, reason, description) VALUES (?, ?, 'inappropriate', 'Reported from anonymous chat')",
            args: [reporterId, reportedUserId]
        });
        
        await ctx.reply('🚨 Report တင်ပြီးပါပြီ။ ကျေးဇူးပါ။', Markup.keyboard([['🔍 ဖူးစာရှင်ရှာမည်', '💓 Pulse'], ['⚙️ Edit Profile', '👤 Profile'], ['🏷️ Interests'], ['❌ Delete Account', '/help']]).resize());
    } catch (error) {
        console.error('Report error:', error);
    }
});

bot.action(/^view_back_(.+)$/, async (ctx) => {
    await ctx.answerCbQuery().catch(() => {});
    
    const senderId = ctx.match[1];
    const sender = await getUser(senderId);
    
    if (!sender) {
        return await ctx.reply("သူ့ Profile မတွေ့ပါ။");
    }
    
    return await ctx.replyWithPhoto(sender.photo_id, {
        caption: `👤 ${sender.nickname} (${sender.age})\n📍 ${sender.address}\n\n📝 ${sender.bio}`,
        ...Markup.inlineKeyboard([
            [Markup.button.callback('❤️ Like', `like_${senderId}`)],
            [Markup.button.callback('➡️ Next', 'next_profile')],
            [Markup.button.callback('ပိတ်မယ်', 'close_profile')]
        ])
    });
});

bot.action('close_profile', async (ctx) => {
    await ctx.answerCbQuery().catch(() => {});
    await ctx.deleteMessage().catch(() => {});
});

// Report user functionality
bot.action(/^report_(\d+)$/, async (ctx) => {
    const targetId = ctx.match[1];
    const reporterId = ctx.from.id;
    
    console.log('Report button clicked - reporter:', reporterId, 'target:', targetId);
    
    // Set user step to waiting for report reason
    await db.execute({ 
        sql: "UPDATE users SET step = ? WHERE telegram_id = ?", 
        args: [`report_reason_${targetId}`, reporterId] 
    });
    
    await ctx.answerCbQuery('🚨 Report');
    
    await ctx.reply(`🚨 *Report User*

ဘယ်အကြောင်းကြောင့် Report လုပ်ချင်ပါသလဲ。

အောက်က ခလုတ်များထဲမှ ရွေးပါ:`, { 
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
            [Markup.button.callback('🎭 Fake Profile', `report_fake_${targetId}`)],
            [Markup.button.callback('📢 Spam', `report_spam_${targetId}`)],
            [Markup.button.callback('⚠️ Inappropriate', `report_inappropriate_${targetId}`)],
            [Markup.button.callback('❌ Cancel', 'cancel_report')]
        ])
    });
});

bot.action(/^report_(fake|spam|inappropriate)_(.+)$/, async (ctx) => {
    const reason = ctx.match[1];
    const targetId = ctx.match[2];
    const reporterId = ctx.from.id;
    
    console.log('Report reason selected:', reason, 'target:', targetId);
    
    // Set user step to waiting for report description
    await db.execute({ 
        sql: "UPDATE users SET step = ? WHERE telegram_id = ?", 
        args: [`report_desc_${reason}_${targetId}`, reporterId] 
    });
    
    await ctx.answerCbQuery();
    
    const reasonText = {
        'fake': '🎭 Fake Profile',
        'spam': '📢 Spam',
        'inappropriate': '⚠️ Inappropriate'
    };
    
    await ctx.reply(`${reasonText[reason]}

အသေးစိတ် ရှင်းပြချက် ရေးပေးပါ (Optional):
ဥပမာ - "ပုံက လူစစ်မဟုတ်ဘူး"`, {
        ...Markup.forceReply()
    });
});

bot.action('cancel_report', async (ctx) => {
    await ctx.answerCbQuery();
    await db.execute({ sql: "UPDATE users SET step = 'done' WHERE telegram_id = ?", args: [ctx.from.id] });
    await ctx.reply('Report ပယ်ဖျက်လိုက်ပါပြီ။');
});

async function handleChat(ctx, user) {
    const text = ctx.message.text;
    
    if (text === '🔙 Back to Main Menu') {
        await ctx.reply('Main Menu သို့ ပြန်သွားပါပြီ။', Markup.keyboard([['🔍 ဖူးစာရှင်ရှာမည်', '💓 Pulse'], ['⚙️ Edit Profile', '👤 Profile'], ['🏷️ Interests'], ['❌ Delete Account', '/help']]).resize());
        return;
    }
    
    if (user.step === 'ask_interests' || user.step === 'edit_interests') {
        if (isReservedUserInput(text)) return await reservedInputReply(ctx);

        if (user.step === 'ask_interests' && text === '/skip') {
            await db.execute({ sql: "UPDATE users SET interests = NULL, is_registered = 1, step = 'done' WHERE telegram_id = ?", args: [ctx.from.id] });
            return await ctx.reply('✅ Registration completed without interests. You can set interests later with /interests', Markup.keyboard([['🔍 ဖူးစာရှင်ရှာမည်', '💓 Pulse'], ['⚙️ Edit Profile', '👤 Profile'], ['🏷️ Interests'], ['❌ Delete Account', '/help']]).resize());
        }

        if (!text || text.trim() === '') return await ctx.reply('ကျေးဇူးပြု၍ interests (tags) တစ်ခုခု ရိုက်ထည့်ပါ၊ ဥပမာ: travel, music, food');

        const parts = text.split(/[;]+|\s+/).map(p => p.trim()).filter(Boolean);
        const normalized = parts.join(',');

        if (user.step === 'ask_interests') {
            await db.execute({ sql: "UPDATE users SET interests = ?, is_registered = 1, step = 'done' WHERE telegram_id = ?", args: [normalized, ctx.from.id] });
            return await ctx.reply('✅ Interests သိမ်းပြီးပါပြီ:' + formatInterests(normalized), Markup.keyboard([['🔍 ဖူးစာရှင်ရှာမည်', '💓 Pulse'], ['⚙️ Edit Profile', '👤 Profile'], ['🏷️ Interests'], ['❌ Delete Account', '/help']]).resize());
        }

        await db.execute({ sql: "UPDATE users SET interests = ?, step = 'done' WHERE telegram_id = ?", args: [normalized, ctx.from.id] });
        return await ctx.reply('✅ Interests သိမ်းပြီးပါပြီ: ' + formatInterests(normalized), Markup.keyboard([['🔍 ဖူးစာရှင်ရှာမည်', '💓 Pulse'], ['⚙️ Edit Profile', '👤 Profile'], ['🏷️ Interests'], ['❌ Delete Account', '/help']]).resize());
    }
    
    // Handle report description input
    if (user?.step?.startsWith('report_desc_')) {
        const stepParts = user.step.replace('report_desc_', '').split('_');
        const reason = stepParts[0];
        const targetId = stepParts[1];
        const reporterId = ctx.from.id;
        const description = text.trim();
        
        console.log('Submitting report - reporter:', reporterId, 'target:', targetId, 'reason:', reason);
        
        // Insert report into database
        await db.execute({
            sql: "INSERT INTO reports (reporter_id, reported_user_id, reason, description, status) VALUES (?, ?, ?, ?, 'pending')",
            args: [reporterId, targetId, reason, description]
        });
        
        // Clear step
        await db.execute({ sql: "UPDATE users SET step = 'done' WHERE telegram_id = ?", args: [reporterId] });
        
        await ctx.reply(`✅ Report တင်ပြီးပါပြီ။

သင့် Report ကို Admin team က စစ်ဆေးပါမည်။
ကျေးဇူးတင်ပါတယ်! 🙏`, Markup.keyboard([['🔍 ဖူးစာရှင်ရှာမည်', '💓 Pulse'], ['⚙️ Edit Profile', '👤 Profile'], ['🏷️ Interests'], ['❌ Delete Account', '/help']]).resize());
        return;
    }
    
    // Handle secret message input
    if (user?.step?.startsWith('secret_message_')) {
        const targetId = user.step.replace('secret_message_', '');
        const senderId = ctx.from.id;
        const secretMessage = text.trim();
        
        if (secretMessage.length < 1 || secretMessage.length > 200) {
            return await ctx.reply("❌ စိတ်ကူးလေးကို ၁လုံးကနေ ၂၀၀လုံးအတွင်းထည့်ပါ။");
        }
        
        // Store the message temporarily
        pendingSecretMessages.set(`${senderId}_${targetId}`, secretMessage);
        
        // Clear step
        await db.execute({ sql: "UPDATE users SET step = 'browse' WHERE telegram_id = ?", args: [senderId] });
        
        await ctx.reply(`💌 စိတ်ကူးလေး သိမ်းဆည်းပြီးပါပြီ။\n\n"${secretMessage}"\n\nအခု Like ခလုတ်နှိပ်လိုက်ရင် စိတ်ကူးလေးနဲ့တွဲပြီး ပို့ပေးပါမယ်။`, {
            reply_markup: {
                inline_keyboard: [[{ text: '❤️ Like + Message', callback_data: `like_${targetId}` }]]
            }
        });
        return;
    }
    
    if (text === '/pulse' || text === '💓 Pulse') {
        const { online, matches } = await stats.getRealStats();
        const pulseText = `💓 *Matching Pulse*\n\n` +
            `👥 စုစုပေါင်း Register လုပ်ထားသူ: *${online}* ယောက်\n` +
            `❤️ ဒီနေ့ Match အရေအတွက်: *${matches}* စုံ\n\n` +
            `🔥 MM Cupid မှာ သင့်ဖူးစာရှင်ကို ရှာဖွေလိုက်ပါ!`;
        return await ctx.reply(pulseText, { parse_mode: 'Markdown' });
    }
    if (text === '/find' || text === '🔍 Find Match' || text === '🔍 ဖူးစာရှင်ရှာမည်') {
        return await showNextProfile(ctx);
    }

    // Main menu Interests button
    if (text === '🏷️ Interests') {
        try {
            const userMenu = await getUser(ctx.from.id);
            if (!userMenu || !userMenu.is_registered) return await ctx.reply('Profile မရှိသေးပါ။ /start နှိပ်ပြီး မှတ်ပုံတင်ပါ။');
            await db.execute({ sql: "UPDATE users SET step = 'ask_interests' WHERE telegram_id = ?", args: [ctx.from.id] });
            return await ctx.reply('သင့်စိတ်ဝင်စားသော အရာများ (tags) ကို ကော်မား သို့မဟုတ် စာလုံးဖြင့် ခွဲ၍ ရိုက်ထည့်ပေးပါ။ ဥပမာ: travel, music, food');
        } catch (error) {
            console.error('Interests button error:', error);
            return await ctx.reply('စနစ်အမှားဖြစ်ပါတယ်။ နောက်မှ ပြန်စမ်းပါ။');
        }
    }

    if (text === '✨ Daily Spark') {
        // Trigger spark command
        const user = await getUser(ctx.from.id);
        if (!user || !user.is_registered) {
            return await ctx.reply("Profile ပြည့်စုံအောင် မှတ်ပုံတင်ပြီးမှ သုံးနိုင်ပါမယ်။ /start နှိပ်ပါ။");
        }
        
        await db.execute({
            sql: "UPDATE users SET step = 'ask_spark' WHERE telegram_id = ?",
            args: [ctx.from.id]
        });
        
        await ctx.reply("✨ *Daily Spark* တင်ပါ\n\nဒီနေ့ ဘာလုပ်ချင်လဲဆိုတဲ့ အခြေအနေကို Emoji လေးနဲ့ ရေးပေးပါ။\n\nဥပမာ: ဒီနေ့ညနေ လှည်းတန်းဘက် ကော်ဖီတူတူသောက်မယ့်သူရှာနေပါတယ် ☕⛈️\n\n(၂၄ နာရီအတွင်း အလိုအလျောက် ပျောက်ပျက်သွားမှာဖြစ်ပါတယ်)", { parse_mode: 'Markdown' });
        return;
    }
    if (text === '❌ Delete Account') {
        // Trigger delete account command
        const user = await getUser(ctx.from.id);
        if (!user || !user.is_registered) {
            return await ctx.reply("Profile မတွေ့ပါ။ /start နှိပ်ပြီး မှတ်ပုံတင်ပါ။");
        }
        
        await ctx.reply("⚠️ *Account ဖျက်မည်မှာ သေချာပါသလား?*\n\nသင့် Profile နဲ့ အချက်အလက်အားလုံး ပျောက်ပျက်သွားမှာဖြစ်ပါတယ်။", {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
                [Markup.button.callback('❌ ဖျက်မည်', 'delete_confirm')],
                [Markup.button.callback('ပယ်ဖျက်မည်', 'delete_cancel')]
            ])
        });
        return;
    }
    if (text === '/edit' || text === '⚙️ Edit Profile') {
        await db.execute({ sql: "UPDATE users SET step = 'edit_menu' WHERE telegram_id = ?", args: [ctx.from.id] });
        return await ctx.reply("ဘာကိုပြင်ဆင်ချင်ပါသလဲ။", Markup.keyboard([['📝 Nickname', '🎂 Age'], ['🏠 Address', '📷 Photo'], ['📄 Bio', '❌ Cancel']]).resize());
    }
    if (text === '/profile' || text === '👤 Profile') return await showMyProfile(ctx);
    if (text === '/help') {
        const helpText = `📋 **MM Cupid Bot Commands**

🔹 /start - Register your profile
🔹 /find - Find matches (🔍 ဖူးစာရှင်ရှာမည်)
🔹 /pulse - Live stats (💓 Pulse)
🔹 /profile - View your profile (👤 Profile)
🔹 /edit - Edit your profile (⚙️ Edit Profile)
🔹 /spark - Set daily spark status
🔹 /deleteaccount - Delete your account (❌ Delete Account)
🔹 /help - Show this help message

💕 ဖူးစာရှင်ကို ရှာဖွေလိုက်ပါ!`;
        return await ctx.reply(helpText, { parse_mode: 'Markdown' });
    }
}

// Dashboard Password (set via env var or use default)
const DASHBOARD_PASSWORD = process.env.DASHBOARD_PASSWORD || 'hidecard';

// Dashboard API Routes - Simplified for Vercel
async function handleDashboardAPI(req, res) {
    // CORS headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Password');
    
    if (req.method === 'OPTIONS') {
        return res.status(200).end();
    }
    
    // Password check (skip for login check endpoint)
    const url = req.url || '';
    if (!url.includes('/api/check-auth')) {
        const password = req.headers['x-password'] || req.query?.password;
        if (password !== DASHBOARD_PASSWORD) {
            return res.status(401).json({ error: 'Unauthorized - Invalid password' });
        }
    }
    
    // Get path from URL
    let path = url;
    console.log('Dashboard API request:', path);
    
    // Remove query params and normalize
    path = path.split('?')[0].replace(/^\//, '');
    console.log('Normalized path:', path);
    
    // Check password endpoint
    if (path === 'api/check-auth' || path === 'check-auth') {
        const password = req.headers['x-password'] || req.query?.password;
        if (password === DASHBOARD_PASSWORD) {
            return res.status(200).json({ success: true });
        }
        return res.status(401).json({ error: 'Invalid password' });
    }
    
    try {
        // Check database connection
        if (!db) {
            console.error('Database not connected');
            return res.status(500).json({ error: 'Database not connected' });
        }
        
        // API: /api/stats - Get dashboard stats
        if (path === 'api/stats' || path === 'stats') {
            console.log('Fetching stats...');
            
            // Get total users
            const totalResult = await db.execute({
                sql: "SELECT COUNT(*) as count FROM users WHERE is_registered = 1",
                args: []
            });
            const totalUsers = totalResult.rows[0]?.count || 0;
            console.log('Total users:', totalUsers);
            
            // Get total matches (mutual likes count)
            const matchesResult = await db.execute({
                sql: "SELECT COUNT(*) as count FROM likes l WHERE EXISTS (SELECT 1 FROM likes l2 WHERE l2.from_user = l.to_user AND l2.to_user = l.from_user)",
                args: []
            });
            const totalMatches = Math.floor((matchesResult.rows[0]?.count || 0) / 2);
            console.log('Total matches:', totalMatches);
            
            return res.status(200).json({
                totalUsers: totalUsers,
                todayMatches: totalMatches,
                lastUpdated: new Date().toISOString()
            });
        }
        
        // API: /api/users - Get user list
        if (path === 'api/users' || path === 'users') {
            console.log('Fetching users...');
            
            const usersResult = await db.execute({
                sql: "SELECT telegram_id, nickname, age, gender, looking_for, address, is_registered FROM users LIMIT 50",
                args: []
            });
            
            const countResult = await db.execute({
                sql: "SELECT COUNT(*) as count FROM users WHERE is_registered = 1",
                args: []
            });
            
            console.log('Users fetched:', usersResult.rows.length);
            
            return res.status(200).json({
                users: usersResult.rows || [],
                total: countResult.rows[0]?.count || 0
            });
        }
        
        // API: /api/matches - Get match list
        if (path === 'api/matches' || path === 'matches') {
            console.log('Fetching matches...');
            
            // Get all mutual likes (matches) - simpler query for SQLite
            const matchesResult = await db.execute({
                sql: "SELECT l.from_user as user1_id, l.to_user as user2_id FROM likes l WHERE EXISTS (SELECT 1 FROM likes l2 WHERE l2.from_user = l.to_user AND l2.to_user = l.from_user) LIMIT 100",
                args: []
            });
            
            // Get unique matches (each match appears twice)
            const seen = new Set();
            const uniqueMatches = [];
            
            for (const row of matchesResult.rows || []) {
                // Create a unique key (smaller ID first)
                const u1 = row.user1_id;
                const u2 = row.user2_id;
                const key = u1 < u2 ? u1 + '-' + u2 : u2 + '-' + u1;
                
                if (!seen.has(key)) {
                    seen.add(key);
                    uniqueMatches.push(row);
                }
            }
            
            // Fetch user nicknames for each match
            const matchesWithNames = [];
            for (const match of uniqueMatches.slice(0, 50)) {
                const [user1Res, user2Res] = await Promise.all([
                    db.execute({
                        sql: "SELECT nickname FROM users WHERE telegram_id = ?",
                        args: [match.user1_id]
                    }),
                    db.execute({
                        sql: "SELECT nickname FROM users WHERE telegram_id = ?",
                        args: [match.user2_id]
                    })
                ]);
                
                matchesWithNames.push({
                    user1: { 
                        id: match.user1_id, 
                        nickname: user1Res.rows[0]?.nickname || 'Unknown'
                    },
                    user2: { 
                        id: match.user2_id, 
                        nickname: user2Res.rows[0]?.nickname || 'Unknown'
                    }
                });
            }
            
            console.log('Matches fetched:', matchesWithNames.length);
            
            return res.status(200).json({
                matches: matchesWithNames,
                total: matchesWithNames.length
            });
        }

        // API: /api/analytics - Advanced statistics
        if (path === 'api/analytics' || path === 'analytics') {
            console.log('Fetching analytics...');
            
            // Gender distribution
            const genderResult = await db.execute({
                sql: "SELECT gender, COUNT(*) as count FROM users WHERE is_registered = 1 GROUP BY gender",
                args: []
            });
            
            // Total likes
            const likesResult = await db.execute({
                sql: "SELECT COUNT(*) as count FROM likes",
                args: []
            });
            
            // Daily active users (users who liked/viewed today)
            const activeTodayResult = await db.execute({
                sql: "SELECT COUNT(DISTINCT user_id) as count FROM profile_views WHERE date(viewed_at) = date('now')",
                args: []
            });
            
            // Users by city
            const citiesResult = await db.execute({
                sql: "SELECT address, COUNT(*) as count FROM users WHERE is_registered = 1 AND address IS NOT NULL GROUP BY address ORDER BY count DESC LIMIT 10",
                args: []
            });
            
            // Age distribution
            const ageResult = await db.execute({
                sql: "SELECT CASE WHEN age < 20 THEN 'Under 20' WHEN age BETWEEN 20 AND 30 THEN '20-30' WHEN age BETWEEN 31 AND 40 THEN '31-40' ELSE '40+' END as range, COUNT(*) as count FROM users WHERE is_registered = 1 GROUP BY range",
                args: []
            });
            
            // Calculate match success rate
            const totalUsers = (await db.execute({ sql: "SELECT COUNT(*) as count FROM users WHERE is_registered = 1", args: [] })).rows[0]?.count || 0;
            const totalLikes = likesResult.rows[0]?.count || 0;
            const totalMatches = Math.floor(((await db.execute({ sql: "SELECT COUNT(*) as count FROM likes l WHERE EXISTS (SELECT 1 FROM likes l2 WHERE l2.from_user = l.to_user AND l2.to_user = l.from_user)", args: [] })).rows[0]?.count || 0) / 2);
            
            const successRate = totalLikes > 0 ? ((totalMatches * 2) / totalLikes * 100).toFixed(1) : 0;
            
            // totalLikes already set from likesResult above
            
            console.log('Analytics fetched');
            
            return res.status(200).json({
                genderDistribution: genderResult.rows || [],
                totalLikes: totalLikes,
                dailyActiveUsers: activeTodayResult.rows[0]?.count || 0,
                topCities: citiesResult.rows || [],
                ageDistribution: ageResult.rows || [],
                matchSuccessRate: successRate + '%',
                totalMatches: totalMatches,
            });
        }

        // API: /api/retention - Retention rate data
        if (path === 'api/retention' || path === 'retention') {
            console.log('Fetching retention data...');
            
            // Get retention data - users who returned after X days
            const retentionResult = await db.execute({
                sql: `SELECT 
                    COUNT(DISTINCT CASE WHEN session_count >= 1 THEN user_id END) as day_1,
                    COUNT(DISTINCT CASE WHEN session_count >= 3 THEN user_id END) as day_3,
                    COUNT(DISTINCT CASE WHEN session_count >= 7 THEN user_id END) as day_7,
                    COUNT(DISTINCT CASE WHEN session_count >= 14 THEN user_id END) as day_14,
                    COUNT(DISTINCT CASE WHEN session_count >= 30 THEN user_id END) as day_30
                FROM (
                    SELECT user_id, COUNT(*) as session_count 
                    FROM user_sessions 
                    WHERE session_date >= date('now', '-30 days')
                    GROUP BY user_id
                )`,
                args: []
            });
            
            // Get daily retention for the last 30 days
            const dailyRetentionResult = await db.execute({
                sql: `SELECT 
                    session_date,
                    COUNT(DISTINCT user_id) as active_users
                FROM user_sessions 
                WHERE session_date >= date('now', '-30 days')
                GROUP BY session_date 
                ORDER BY session_date ASC`,
                args: []
            });
            
            const retentionRow = retentionResult.rows[0] || {};
            const totalUsers = (await db.execute({ sql: "SELECT COUNT(*) as count FROM users WHERE is_registered = 1", args: [] })).rows[0]?.count || 0;
            
            return res.status(200).json({
                day1: Math.round((retentionRow.day_1 || 0) / (totalUsers || 1) * 100),
                day3: Math.round((retentionRow.day_3 || 0) / (totalUsers || 1) * 100),
                day7: Math.round((retentionRow.day_7 || 0) / (totalUsers || 1) * 100),
                day14: Math.round((retentionRow.day_14 || 0) / (totalUsers || 1) * 100),
                day30: Math.round((retentionRow.day_30 || 0) / (totalUsers || 1) * 100),
                dailyRetention: dailyRetentionResult.rows || [],
                totalUsers: totalUsers
            });
        }

        // API: /api/dau - Daily Active Users historical data
        if (path === 'api/dau' || path === 'dau') {
            console.log('Fetching DAU data...');
            
            const days = parseInt(req.query?.days) || 30;
            
            // Get DAU for the last N days
            const dauResult = await db.execute({
                sql: `SELECT 
                    session_date,
                    COUNT(DISTINCT user_id) as dau,
                    SUM(activities_count) as total_activities
                FROM user_sessions 
                WHERE session_date >= date('now', '-${days} days')
                GROUP BY session_date 
                ORDER BY session_date ASC`,
                args: []
            });
            
            // Also get MAU (Monthly Active Users)
            const mauResult = await db.execute({
                sql: `SELECT COUNT(DISTINCT user_id) as mau 
                FROM user_sessions 
                WHERE session_date >= date('now', '-30 days')`,
                args: []
            });
            
            return res.status(200).json({
                dailyData: dauResult.rows || [],
                mau: mauResult.rows[0]?.mau || 0,
                period: days
            });
        }

        // API: /api/swipes - Swipe activity data
        if (path === 'api/swipes' || path === 'swipes') {
            console.log('Fetching swipe data...');
            
            const days = parseInt(req.query?.days) || 30;
            
            try {
                // Get daily swipe (like) counts
                const swipeResult = await db.execute({
                    sql: `SELECT 
                        date(created_at) as swipe_date,
                        COUNT(*) as swipe_count,
                        COUNT(DISTINCT from_user) as unique_swipers
                    FROM likes 
                    WHERE created_at >= date('now', '-${days} days')
                    GROUP BY date(created_at)
                    ORDER BY swipe_date ASC`,
                    args: []
                });
                
                // Get profile view counts
                const viewResult = await db.execute({
                    sql: `SELECT 
                        date(viewed_at) as view_date,
                        COUNT(*) as view_count,
                        COUNT(DISTINCT user_id) as unique_viewers
                    FROM profile_views 
                    WHERE viewed_at >= date('now', '-${days} days')
                    GROUP BY date(viewed_at)
                    ORDER BY view_date ASC`,
                    args: []
                });
                
                return res.status(200).json({
                    swipeData: swipeResult.rows || [],
                    viewData: viewResult.rows || [],
                    period: days
                });
            } catch (error) {
                console.error('Swipe data fetch error:', error);
                // Return empty data if the query fails (e.g., created_at column doesn't exist yet)
                return res.status(200).json({
                    swipeData: [],
                    viewData: [],
                    period: days
                });
            }
        }

        // API: /api/search - Search users
        if (path === 'api/search' || path === 'search') {
            const searchQuery = req.query?.q || '';
            const searchType = req.query?.type || 'nickname'; // nickname, city, age
            
            console.log('Searching:', searchType, searchQuery);
            
            let sql, params = [];
            
            if (searchType === 'nickname' && searchQuery) {
                sql = "SELECT telegram_id, nickname, age, gender, looking_for, address, is_registered, bio FROM users WHERE nickname LIKE ? AND is_registered = 1 LIMIT 50";
                params = ['%' + searchQuery + '%'];
            } else if (searchType === 'city' && searchQuery) {
                sql = "SELECT telegram_id, nickname, age, gender, looking_for, address, is_registered, bio FROM users WHERE address LIKE ? AND is_registered = 1 LIMIT 50";
                params = ['%' + searchQuery + '%'];
            } else if (searchType === 'age' && searchQuery) {
                sql = "SELECT telegram_id, nickname, age, gender, looking_for, address, is_registered, bio FROM users WHERE age = ? AND is_registered = 1 LIMIT 50";
                params = [parseInt(searchQuery)];
            } else {
                sql = "SELECT telegram_id, nickname, age, gender, looking_for, address, is_registered, bio FROM users WHERE is_registered = 1 LIMIT 50";
            }
            
            const usersResult = await db.execute({ sql, args: params });
            
            return res.status(200).json({
                users: usersResult.rows || [],
                query: searchQuery,
                type: searchType
            });
        }

        // API: /api/ban - Ban/unban/shadowban user
        if (path === 'api/ban' || path === 'ban') {
            if (req.method !== 'POST') {
                return res.status(405).json({ error: 'Method not allowed' });
            }
            
            const { userId, action, reason } = req.body || {};
            
            if (!userId) {
                return res.status(400).json({ error: 'User ID required' });
            }
            
            console.log('Ban action:', action, 'User:', userId, 'Reason:', reason);
            
            if (action === 'ban') {
                await db.execute({
                    sql: "UPDATE users SET is_banned = 1, is_shadowbanned = 0, ban_reason = ?, banned_at = CURRENT_TIMESTAMP, banned_by = ? WHERE telegram_id = ?",
                    args: [reason || 'Violation of terms', req.headers['x-admin-id'] || 0, userId]
                });
                return res.status(200).json({ success: true, message: 'User banned' });
            } else if (action === 'unban') {
                await db.execute({
                    sql: "UPDATE users SET is_banned = 0, is_shadowbanned = 0, ban_reason = NULL, banned_at = NULL, banned_by = NULL WHERE telegram_id = ?",
                    args: [userId]
                });
                return res.status(200).json({ success: true, message: 'User unbanned' });
            } else if (action === 'shadowban') {
                await db.execute({
                    sql: "UPDATE users SET is_banned = 0, is_shadowbanned = 1, ban_reason = ?, banned_at = CURRENT_TIMESTAMP, banned_by = ? WHERE telegram_id = ?",
                    args: [reason || 'Shadowban', req.headers['x-admin-id'] || 0, userId]
                });
                return res.status(200).json({ success: true, message: 'User shadowbanned' });
            } else if (action === 'unshadowban') {
                await db.execute({
                    sql: "UPDATE users SET is_shadowbanned = 0, ban_reason = NULL, banned_at = NULL, banned_by = NULL WHERE telegram_id = ?",
                    args: [userId]
                });
                return res.status(200).json({ success: true, message: 'User unshadowbanned' });
            }
            
            return res.status(400).json({ error: 'Invalid action' });
        }

        // API: /api/delete-user - Delete user
        if (path === 'api/delete-user' || path === 'delete-user') {
            if (req.method !== 'POST') {
                return res.status(405).json({ error: 'Method not allowed' });
            }
            
            const { userId } = req.body || {};
            
            if (!userId) {
                return res.status(400).json({ error: 'User ID required' });
            }
            
            console.log('Deleting user:', userId);
            
            // Delete from all related tables
            await db.execute({ sql: "DELETE FROM likes WHERE from_user = ? OR to_user = ?", args: [userId, userId] });
            await db.execute({ sql: "DELETE FROM profile_views WHERE user_id = ? OR viewed_profile_id = ?", args: [userId, userId] });
            await db.execute({ sql: "DELETE FROM users WHERE telegram_id = ?", args: [userId] });
            
            return res.status(200).json({ success: true, message: 'User deleted' });
        }

        // API: /api/banned-users - Get banned users list
        if (path === 'api/banned-users' || path === 'banned-users') {
            const bannedResult = await db.execute({
                sql: "SELECT telegram_id, nickname, is_banned, is_shadowbanned, ban_reason, banned_at FROM users WHERE is_banned = 1 OR is_shadowbanned = 1 ORDER BY banned_at DESC",
                args: []
            });
            
            return res.status(200).json({
                bannedUsers: bannedResult.rows || []
            });
        }

        // API: /api/reports - Get reports list
        if (path === 'api/reports' || path === 'reports') {
            const reportsResult = await db.execute({
                sql: `SELECT r.*, 
                      reporter.nickname as reporter_name, 
                      reported.nickname as reported_name 
                      FROM reports r 
                      LEFT JOIN users reporter ON r.reporter_id = reporter.telegram_id 
                      LEFT JOIN users reported ON r.reported_user_id = reported.telegram_id 
                      ORDER BY r.created_at DESC LIMIT 100`,
                args: []
            });
            
            return res.status(200).json({
                reports: reportsResult.rows || []
            });
        }

        // API: /api/review-report - Review and take action on a report
        if (path === 'api/review-report' || path === 'review-report') {
            if (req.method !== 'POST') {
                return res.status(405).json({ error: 'Method not allowed' });
            }
            
            const { reportId, action, actionTaken } = req.body || {};
            
            if (!reportId || !action) {
                return res.status(400).json({ error: 'Report ID and action required' });
            }
            
            console.log('Review report:', reportId, 'Action:', action, 'ActionTaken:', actionTaken);
            
            const adminId = req.headers['x-admin-id'] || 0;
            
            // Update report status
            await db.execute({
                sql: "UPDATE reports SET status = ?, reviewed_at = CURRENT_TIMESTAMP, reviewed_by = ?, action_taken = ? WHERE id = ?",
                args: [action, adminId, actionTaken || 'no_action', reportId]
            });
            
            return res.status(200).json({ success: true, message: 'Report reviewed' });
        }
        
        console.log('Unknown path:', path);
        return res.status(404).json({ error: 'Not found', path });
    } catch (error) {
        console.error('Dashboard API Error:', error);
        return res.status(500).json({ 
            error: 'Internal server error', 
            message: error.message,
            stack: error.stack 
        });
    }
}

// Vercel Handler - Ensures all async operations complete
export default async (req, res) => {
    // Handle Dashboard API routes
    if (req.url?.startsWith('/api/stats') || req.url?.startsWith('/api/users') || req.url?.startsWith('/api/matches') ||
        req.url?.startsWith('/api/analytics') || req.url?.startsWith('/api/search') || 
        req.url?.startsWith('/api/ban') || req.url?.startsWith('/api/delete-user') || 
        req.url?.startsWith('/api/banned-users') || req.url?.startsWith('/api/reports') ||
        req.url?.startsWith('/api/review-report') || req.url?.startsWith('/api/check-auth') ||
        req.url?.startsWith('/api/retention') || req.url?.startsWith('/api/dau') || req.url?.startsWith('/api/swipes') ||
        req.url === '/stats' || req.url === '/users' || req.url === '/matches' || req.url === '/analytics' || 
        req.url === '/search' || req.url === '/ban' || req.url === '/delete-user' || req.url === '/banned-users' ||
        req.url === '/reports' || req.url === '/review-report' || req.url === '/check-auth' ||
        req.url === '/retention' || req.url === '/dau' || req.url === '/swipes') {
        return handleDashboardAPI(req, res);
    }
    
    // Serve dashboard HTML for root path
    if (req.method === 'GET' && (req.url === '/' || req.url === '/dashboard' || req.url === '/api' || req.url === '/api/')) {
        res.setHeader('Content-Type', 'text/html');
        return res.status(200).send(dashboardHTML);
    }
    
    // Bot webhook handler
    if (req.method !== 'POST') return res.status(200).send('Bot is running. POST to this endpoint for webhook. Dashboard at /');
    
    console.log('Received update:', req.body?.update_id, 'Type:', Object.keys(req.body || {})[1]);
    
    try {
        // Create a promise that resolves when all bot processing is done
        await new Promise((resolve, reject) => {
            const timeout = setTimeout(() => {
                console.warn('Bot processing timeout - forcing response');
                resolve();
            }, 9000); // 9 second timeout for Vercel
            
            bot.handleUpdate(req.body)
                .then(() => {
                    clearTimeout(timeout);
                    // Give a small delay for any background DB operations
                    setTimeout(resolve, 200);
                })
                .catch((err) => {
                    clearTimeout(timeout);
                    reject(err);
                });
        });
        
        console.log('Update processed successfully');
        res.status(200).json({ ok: true });
    } catch (error) {
        console.error('Webhook Error:', error);
        res.status(200).json({ ok: true });
    }
};

// Dashboard HTML with React
const dashboardHTML = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MM Cupid Dashboard</title>
    <script src="https://unpkg.com/react@18/umd/react.production.min.js" crossorigin></script>
    <script src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js" crossorigin></script>
    <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div id="root"></div>
    <script type="text/babel">
        const { useState, useEffect } = React;

        // Card Component
        const StatCard = ({ title, value, icon, color, trend }) => (
            <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100 hover:shadow-lg transition-shadow">
                <div className="flex items-center justify-between">
                    <div>
                        <p className="text-sm text-gray-500 mb-1">{title}</p>
                        <h3 className="text-2xl font-bold text-gray-800">{value}</h3>
                        {trend && (
                            <p className="text-xs text-green-500 mt-1">
                                <i className="fas fa-arrow-up mr-1"></i>{trend}
                            </p>
                        )}
                    </div>
                    <div className={\`w-12 h-12 rounded-full \${color} flex items-center justify-center text-white text-xl\`}>
                        <i className={\`fas \${icon}\`}></i>
                    </div>
                </div>
            </div>
        );

        // Line Chart Component
        const LineChart = ({ data, label, color, title }) => {
            const chartRef = React.useRef(null);
            const chartInstance = React.useRef(null);

            useEffect(() => {
                if (chartRef.current && data) {
                    if (chartInstance.current) {
                        chartInstance.current.destroy();
                    }

                    const ctx = chartRef.current.getContext('2d');
                    chartInstance.current = new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: data.map(d => d.date || d.session_date || d.swipe_date || d.view_date),
                            datasets: [{
                                label: label,
                                data: data.map(d => d.count || d.dau || d.active_users || d.swipe_count || d.view_count),
                                borderColor: color,
                                backgroundColor: color + '20',
                                fill: true,
                                tension: 0.4
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                legend: {
                                    display: true,
                                    position: 'top'
                                }
                            },
                            scales: {
                                y: {
                                    beginAtZero: true
                                }
                            }
                        }
                    });
                }

                return () => {
                    if (chartInstance.current) {
                        chartInstance.current.destroy();
                    }
                };
            }, [data, label, color]);

            return (
                <div className="bg-white rounded-xl shadow-md p-6">
                    <h3 className="text-lg font-semibold mb-4">{title}</h3>
                    <div style={{ height: '300px' }}>
                        <canvas ref={chartRef}></canvas>
                    </div>
                </div>
            );
        };

        // Retention Chart Component
        const RetentionChart = ({ data }) => {
            const chartRef = React.useRef(null);
            const chartInstance = React.useRef(null);

            useEffect(() => {
                if (chartRef.current && data) {
                    if (chartInstance.current) {
                        chartInstance.current.destroy();
                    }

                    const ctx = chartRef.current.getContext('2d');
                    chartInstance.current = new Chart(ctx, {
                        type: 'bar',
                        data: {
                            labels: ['Day 1', 'Day 3', 'Day 7', 'Day 14', 'Day 30'],
                            datasets: [{
                                label: 'Retention Rate %',
                                data: [data.day1, data.day3, data.day7, data.day14, data.day30],
                                backgroundColor: [
                                    'rgba(236, 72, 153, 0.8)',
                                    'rgba(236, 72, 153, 0.7)',
                                    'rgba(236, 72, 153, 0.6)',
                                    'rgba(236, 72, 153, 0.5)',
                                    'rgba(236, 72, 153, 0.4)'
                                ],
                                borderColor: 'rgba(236, 72, 153, 1)',
                                borderWidth: 1
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                legend: {
                                    display: true,
                                    position: 'top'
                                }
                            },
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    max: 100,
                                    ticks: {
                                        callback: function(value) {
                                            return value + '%';
                                        }
                                    }
                                }
                            }
                        }
                    });
                }

                return () => {
                    if (chartInstance.current) {
                        chartInstance.current.destroy();
                    }
                };
            }, [data]);

            return (
                <div className="bg-white rounded-xl shadow-md p-6">
                    <h3 className="text-lg font-semibold mb-4">User Retention Rate</h3>
                    <div style={{ height: '300px' }}>
                        <canvas ref={chartRef}></canvas>
                    </div>
                </div>
            );
        };

        // User List Component
        const UserList = ({ users, loading }) => {
            if (loading) return <div className="text-center py-8"><i className="fas fa-spinner fa-spin text-3xl text-pink-500"></i></div>;
            
            return (
                <div className="bg-white rounded-xl shadow-md overflow-hidden">
                    <div className="overflow-x-auto">
                        <table className="w-full">
                            <thead className="bg-gray-50">
                                <tr>
                                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">User</th>
                                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Age</th>
                                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Gender</th>
                                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Looking For</th>
                                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100">
                                {users.map((user) => (
                                    <tr key={user.telegram_id} className="hover:bg-gray-50">
                                        <td className="px-4 py-3">
                                            <div className="flex items-center">
                                                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-pink-400 to-red-500 flex items-center justify-center text-white text-sm font-medium mr-3">
                                                    {user.nickname?.charAt(0)?.toUpperCase() || '?'}
                                                </div>
                                                <span className="font-medium text-gray-800">{user.nickname}</span>
                                            </div>
                                        </td>
                                        <td className="px-4 py-3 text-gray-600">{user.age}</td>
                                        <td className="px-4 py-3">
                                            <span className={\`px-2 py-1 rounded-full text-xs \${user.gender === 'male' ? 'bg-blue-100 text-blue-600' : 'bg-pink-100 text-pink-600'}\`}>
                                                {user.gender?.toUpperCase()}
                                            </span>
                                        </td>
                                        <td className="px-4 py-3">
                                            <span className={\`px-2 py-1 rounded-full text-xs \${user.looking_for === 'male' ? 'bg-blue-100 text-blue-600' : 'bg-pink-100 text-pink-600'}\`}>
                                                {user.looking_for?.toUpperCase()}
                                            </span>
                                        </td>
                                        <td className="px-4 py-3">
                                            <span className={\`px-2 py-1 rounded-full text-xs \${user.is_registered ? 'bg-green-100 text-green-600' : 'bg-yellow-100 text-yellow-600'}\`}>
                                                {user.is_registered ? 'Active' : 'Pending'}
                                            </span>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            );
        };

        // Match List Component
        const MatchList = ({ matches, loading }) => {
            if (loading) return <div className="text-center py-8"><i className="fas fa-spinner fa-spin text-3xl text-pink-500"></i></div>;
            
            return (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {matches.map((match, index) => (
                        <div key={index} className="bg-white rounded-xl shadow-md p-4 border border-gray-100">
                            <div className="flex items-center justify-center mb-4">
                                <div className="flex items-center">
                                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white font-medium">
                                        {match.user1.nickname?.charAt(0)?.toUpperCase()}
                                    </div>
                                    <div className="mx-2 text-red-500">
                                        <i className="fas fa-heart"></i>
                                    </div>
                                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-pink-400 to-red-500 flex items-center justify-center text-white font-medium">
                                        {match.user2.nickname?.charAt(0)?.toUpperCase()}
                                    </div>
                                </div>
                            </div>
                            <div className="text-center">
                                <p className="font-medium text-gray-800">{match.user1.nickname} ❤️ {match.user2.nickname}</p>
                                <p className="text-xs text-pink-500 mt-1">
                                    <i className="fas fa-heart mr-1"></i>Match!
                                </p>
                            </div>
                        </div>
                    ))}
                </div>
            );
        };

        // Login Component
        const LoginScreen = ({ onLogin, loginError }) => {
            const [password, setPassword] = useState('');
            const [showPassword, setShowPassword] = useState(false);

            const handleSubmit = (e) => {
                e.preventDefault();
                onLogin(password);
            };

            return (
                <div className="min-h-screen bg-gradient-to-br from-pink-500 via-red-500 to-purple-600 flex items-center justify-center p-4">
                    <div className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-md">
                        <div className="text-center mb-8">
                            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-pink-500 to-red-600 flex items-center justify-center text-white text-3xl mx-auto mb-4">
                                <i className="fas fa-heart"></i>
                            </div>
                            <h1 className="text-2xl font-bold text-gray-800">MM Cupid</h1>
                            <p className="text-gray-500">Admin Dashboard</p>
                        </div>

                        <form onSubmit={handleSubmit}>
                            <div className="mb-4">
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Password
                                </label>
                                <div className="relative">
                                    <input
                                        type={showPassword ? 'text' : 'password'}
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                        className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-pink-500 focus:border-transparent outline-none"
                                        placeholder="Enter password"
                                        autoFocus
                                    />
                                    <button
                                        type="button"
                                        onClick={() => setShowPassword(!showPassword)}
                                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                                    >
                                        <i className={\`fas \${showPassword ? 'fa-eye-slash' : 'fa-eye'}\`}></i>
                                    </button>
                                </div>
                            </div>

                            {loginError && (
                                <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                                    <p className="text-red-600 text-sm">
                                        <i className="fas fa-exclamation-circle mr-2"></i>
                                        {loginError}
                                    </p>
                                </div>
                            )}

                            <button
                                type="submit"
                                className="w-full py-3 bg-gradient-to-r from-pink-500 to-red-600 text-white rounded-lg font-medium hover:from-pink-600 hover:to-red-700 transition-all transform hover:scale-[1.02]"
                            >
                                <i className="fas fa-lock mr-2"></i>Login
                            </button>
                        </form>

                        <div className="mt-6 text-center">
                            <p className="text-xs text-gray-400">
                                Default: admin123
                            </p>
                        </div>
                    </div>
                </div>
            );
        };

        // Main Dashboard Component
        const Dashboard = () => {
            const [stats, setStats] = useState({ totalUsers: 0, todayMatches: 0 });
            const [users, setUsers] = useState([]);
            const [matches, setMatches] = useState([]);
            const [activeTab, setActiveTab] = useState('overview');
            const [loading, setLoading] = useState(true);
            const [lastUpdate, setLastUpdate] = useState(new Date());
            const [error, setError] = useState(null);
            const [isLoggedIn, setIsLoggedIn] = useState(false);
            const [password, setPassword] = useState('');
            const [loginError, setLoginError] = useState('');
            
            // Analytics state
            const [analytics, setAnalytics] = useState({
                genderDistribution: [],
                totalLikes: 0,
                dailyActiveUsers: 0,
                topCities: [],
                ageDistribution: [],
                matchSuccessRate: '0%',
                totalMatches: 0,
            });
            
            // New analytics state for graphs
            const [retentionData, setRetentionData] = useState(null);
            const [dauData, setDauData] = useState(null);
            const [swipeData, setSwipeData] = useState(null);
            
            // Search state
            const [searchQuery, setSearchQuery] = useState('');
            const [searchType, setSearchType] = useState('nickname');
            const [searchResults, setSearchResults] = useState([]);
            const [searchLoading, setSearchLoading] = useState(false);
            
            // Moderation state
            const [bannedUsers, setBannedUsers] = useState([]);
            const [reports, setReports] = useState([]);
            const [actionMessage, setActionMessage] = useState('');

            const API_URL = '';

            const handleLogin = async (pwd) => {
                setPassword(pwd);
                setLoginError('');
                
                try {
                    const res = await fetch(\`\${API_URL}/api/check-auth?password=\${encodeURIComponent(pwd)}\`);
                    if (res.ok) {
                        setIsLoggedIn(true);
                        sessionStorage.setItem('dashboardPassword', pwd);
                    } else {
                        setLoginError('Invalid password');
                    }
                } catch (err) {
                    setLoginError('Connection error');
                }
            };

            // Check for saved password on mount
            useEffect(() => {
                const savedPwd = sessionStorage.getItem('dashboardPassword');
                if (savedPwd) {
                    handleLogin(savedPwd);
                }
            }, []);

            const fetchData = async () => {
                if (!isLoggedIn || !password) return;
                
                try {
                    setLoading(true);
                    setError(null);
                    
                    console.log('Fetching dashboard data...');
                    
                    const headers = { 'X-Password': password };
                    
                    const [statsRes, usersRes, matchesRes, analyticsRes, bannedRes, reportsRes, retentionRes, dauRes, swipeRes] = await Promise.all([
                        fetch(\`\${API_URL}/api/stats\`, { headers }).then(async r => {
                            if (!r.ok) throw new Error(\`Stats API error: \${r.status}\`);
                            return r.json();
                        }),
                        fetch(\`\${API_URL}/api/users\`, { headers }).then(async r => {
                            if (!r.ok) throw new Error(\`Users API error: \${r.status}\`);
                            return r.json();
                        }),
                        fetch(\`\${API_URL}/api/matches\`, { headers }).then(async r => {
                            if (!r.ok) throw new Error(\`Matches API error: \${r.status}\`);
                            return r.json();
                        }),
                        fetch(\`\${API_URL}/api/analytics\`, { headers }).then(async r => {
                            if (!r.ok) throw new Error(\`Analytics API error: \${r.status}\`);
                            return r.json();
                        }),
                        fetch(\`\${API_URL}/api/banned-users\`, { headers }).then(async r => {
                            if (!r.ok) return { bannedUsers: [] };
                            return r.json();
                        }),
                        fetch(\`\${API_URL}/api/reports\`, { headers }).then(async r => {
                            if (!r.ok) return { reports: [] };
                            return r.json();
                        }),
                        fetch(\`\${API_URL}/api/retention\`, { headers }).then(async r => {
                            if (!r.ok) return null;
                            return r.json();
                        }),
                        fetch(\`\${API_URL}/api/dau\`, { headers }).then(async r => {
                            if (!r.ok) return null;
                            return r.json();
                        }),
                        fetch(\`\${API_URL}/api/swipes\`, { headers }).then(async r => {
                            if (!r.ok) return null;
                            return r.json();
                        })
                    ]);
                    
                    console.log('Stats:', statsRes);
                    console.log('Users:', usersRes);
                    console.log('Matches:', matchesRes);
                    console.log('Analytics:', analyticsRes);
                    
                    if (statsRes.error) throw new Error(statsRes.error);
                    if (usersRes.error) throw new Error(usersRes.error);
                    if (matchesRes.error) throw new Error(matchesRes.error);
                    
                    setStats(statsRes);
                    setUsers(usersRes.users || []);
                    setMatches(matchesRes.matches || []);
                    setAnalytics(analyticsRes || {});
                    setBannedUsers(bannedRes?.bannedUsers || []);
                    setReports(reportsRes?.reports || []);
                    setRetentionData(retentionRes);
                    setDauData(dauRes);
                    setSwipeData(swipeRes);
                    setLastUpdate(new Date());
                } catch (error) {
                    console.error('Error fetching data:', error);
                    setError(error.message);
                } finally {
                    setLoading(false);
                }
            };

            // Search function
            const handleSearch = async () => {
                if (!searchQuery.trim()) return;
                
                setSearchLoading(true);
                try {
                    const headers = { 'X-Password': password };
                    const res = await fetch(\`\${API_URL}/api/search?type=\${searchType}&q=\${encodeURIComponent(searchQuery)}\`, { headers });
                    const data = await res.json();
                    setSearchResults(data.users || []);
                } catch (err) {
                    console.error('Search error:', err);
                } finally {
                    setSearchLoading(false);
                }
            };

            // Ban user function
            const handleBanUser = async (userId, action) => {
                try {
                    const headers = { 
                        'X-Password': password,
                        'Content-Type': 'application/json'
                    };
                    const res = await fetch(\`\${API_URL}/api/ban\`, {
                        method: 'POST',
                        headers,
                        body: JSON.stringify({ userId, action })
                    });
                    const data = await res.json();
                    if (data.success) {
                        setActionMessage(\`User \${action === 'ban' ? 'banned' : 'unbanned'} successfully\`);
                        fetchData(); // Refresh data
                        setTimeout(() => setActionMessage(''), 3000);
                    }
                } catch (err) {
                    console.error('Ban error:', err);
                    setActionMessage('Error performing action');
                }
            };

            // Delete user function
            const handleDeleteUser = async (userId) => {
                if (!confirm('Are you sure you want to delete this user? This cannot be undone.')) return;
                
                try {
                    const headers = { 
                        'X-Password': password,
                        'Content-Type': 'application/json'
                    };
                    const res = await fetch(\`\${API_URL}/api/delete-user\`, {
                        method: 'POST',
                        headers,
                        body: JSON.stringify({ userId })
                    });
                    const data = await res.json();
                    if (data.success) {
                        setActionMessage('User deleted successfully');
                        fetchData(); // Refresh data
                        setTimeout(() => setActionMessage(''), 3000);
                    }
                } catch (err) {
                    console.error('Delete error:', err);
                    setActionMessage('Error deleting user');
                }
            };

            // Review report function
            const handleReviewReport = async (reportId, action, actionTaken) => {
                try {
                    const headers = { 
                        'X-Password': password,
                        'Content-Type': 'application/json'
                    };
                    const res = await fetch(\`\${API_URL}/api/review-report\`, {
                        method: 'POST',
                        headers,
                        body: JSON.stringify({ reportId, action, actionTaken })
                    });
                    const data = await res.json();
                    if (data.success) {
                        setActionMessage(\`Report \${action} successfully\`);
                        fetchData(); // Refresh data
                        setTimeout(() => setActionMessage(''), 3000);
                    }
                } catch (err) {
                    console.error('Review error:', err);
                    setActionMessage('Error reviewing report');
                }
            };

            useEffect(() => {
                if (isLoggedIn && password) {
                    fetchData();
                    const interval = setInterval(fetchData, 30000); // Refresh every 30 seconds
                    return () => clearInterval(interval);
                }
            }, [isLoggedIn, password]);

            // Show login screen if not authenticated
            if (!isLoggedIn) {
                return <LoginScreen onLogin={handleLogin} loginError={loginError} />;
            }

            return (
                <div className="min-h-screen bg-gray-50">
                    {/* Header */}
                    <header className="bg-white shadow-sm border-b border-gray-200">
                        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
                            <div className="flex items-center justify-between">
                                <div className="flex items-center">
                                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-pink-500 to-red-600 flex items-center justify-center text-white mr-3">
                                        <i className="fas fa-heart"></i>
                                    </div>
                                    <div>
                                        <h1 className="text-xl font-bold text-gray-800">MM Cupid</h1>
                                        <p className="text-xs text-gray-500">Admin Dashboard</p>
                                    </div>
                                </div>
                                <div className="flex items-center space-x-4">
                                    <span className="text-sm text-gray-500">
                                        Last updated: {lastUpdate.toLocaleTimeString()}
                                    </span>
                                    <button 
                                        onClick={fetchData}
                                        className="p-2 rounded-lg bg-pink-50 text-pink-600 hover:bg-pink-100 transition-colors"
                                    >
                                        <i className={\`fas fa-sync-alt \${loading ? 'fa-spin' : ''}\`}></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </header>

                    {/* Navigation */}
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
                        <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg w-fit mb-6">
                            {[
                                { id: 'overview', label: 'Overview', icon: 'fa-chart-line' },
                                { id: 'analytics', label: 'Analytics', icon: 'fa-chart-pie' },
                                { id: 'users', label: 'Users', icon: 'fa-users' },
                                { id: 'search', label: 'Search', icon: 'fa-search' },
                                { id: 'matches', label: 'Matches', icon: 'fa-heart' },
                                { id: 'reports', label: 'Reports', icon: 'fa-flag' },
                                { id: 'moderation', label: 'Moderation', icon: 'fa-shield-alt' }
                            ].map((tab) => (
                                <button
                                    key={tab.id}
                                    onClick={() => setActiveTab(tab.id)}
                                    className={\`px-4 py-2 rounded-md text-sm font-medium transition-all \${
                                        activeTab === tab.id 
                                            ? 'bg-white text-pink-600 shadow-sm' 
                                            : 'text-gray-600 hover:text-gray-800'
                                    }\`}
                                >
                                    <i className={\`fas \${tab.icon} mr-2\`}></i>
                                    {tab.label}
                                </button>
                            ))}
                        </div>

                        {/* Error Display */}
                        {error && (
                            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
                                <div className="flex items-center">
                                    <i className="fas fa-exclamation-circle text-red-500 mr-3"></i>
                                    <div>
                                        <p className="text-red-800 font-medium">Error loading data</p>
                                        <p className="text-red-600 text-sm">{error}</p>
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* Content */}
                        {activeTab === 'overview' && (
                            <div className="space-y-6">
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                    <StatCard 
                                        title="Total Users" 
                                        value={stats.totalUsers} 
                                        icon="fa-users" 
                                        color="bg-blue-500"
                                        trend="All time"
                                    />
                                    <StatCard 
                                        title="Today's Matches" 
                                        value={stats.todayMatches} 
                                        icon="fa-heart" 
                                        color="bg-pink-500"
                                        trend="Real-time"
                                    />
                                    <StatCard 
                                        title="Active Now" 
                                        value={users.filter(u => u.is_registered).length} 
                                        icon="fa-signal" 
                                        color="bg-green-500"
                                        trend="Registered"
                                    />
                                </div>

                                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                    <div className="bg-white rounded-xl shadow-md p-6">
                                        <h3 className="text-lg font-bold text-gray-800 mb-4">
                                            <i className="fas fa-users mr-2 text-blue-500"></i>
                                            Recent Users
                                        </h3>
                                        <UserList users={users.slice(0, 5)} loading={loading} />
                                    </div>
                                    <div className="bg-white rounded-xl shadow-md p-6">
                                        <h3 className="text-lg font-bold text-gray-800 mb-4">
                                            <i className="fas fa-heart mr-2 text-pink-500"></i>
                                            Recent Matches
                                        </h3>
                                        <MatchList matches={matches.slice(0, 6)} loading={loading} />
                                    </div>
                                </div>
                            </div>
                        )}

                        {activeTab === 'users' && (
                            <div>
                                <div className="flex items-center justify-between mb-4">
                                    <h2 className="text-xl font-bold text-gray-800">All Users</h2>
                                    <span className="text-sm text-gray-500">Total: {users.length}</span>
                                </div>
                                <UserList users={users} loading={loading} />
                            </div>
                        )}

                        {activeTab === 'matches' && (
                            <div>
                                <div className="flex items-center justify-between mb-4">
                                    <h2 className="text-xl font-bold text-gray-800">All Matches</h2>
                                    <span className="text-sm text-gray-500">Total: {matches.length}</span>
                                </div>
                                <MatchList matches={matches} loading={loading} />
                            </div>
                        )}

                        {activeTab === 'analytics' && (
                            <div className="space-y-6">
                                <h2 className="text-xl font-bold text-gray-800">Analytics</h2>
                                
                                {/* Stats Cards */}
                                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                                    <div className="bg-white rounded-xl shadow-md p-4">
                                        <p className="text-sm text-gray-500">Total Likes</p>
                                        <p className="text-2xl font-bold text-pink-600">{analytics.totalLikes || 0}</p>
                                    </div>
                                    <div className="bg-white rounded-xl shadow-md p-4">
                                        <p className="text-sm text-gray-500">Daily Active Users</p>
                                        <p className="text-2xl font-bold text-blue-600">{analytics.dailyActiveUsers || 0}</p>
                                    </div>
                                    <div className="bg-white rounded-xl shadow-md p-4">
                                        <p className="text-sm text-gray-500">Match Success Rate</p>
                                        <p className="text-2xl font-bold text-green-600">{analytics.matchSuccessRate || '0%'}</p>
                                    </div>
                                    <div className="bg-white rounded-xl shadow-md p-4">
                                        <p className="text-sm text-gray-500">Total Matches</p>
                                        <p className="text-2xl font-bold text-red-600">{analytics.totalMatches || 0}</p>
                                    </div>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    {/* Gender Distribution */}
                                    <div className="bg-white rounded-xl shadow-md p-6">
                                        <h3 className="text-lg font-semibold mb-4">Gender Distribution</h3>
                                        <div className="space-y-3">
                                            {(analytics.genderDistribution || []).map((g, i) => (
                                                <div key={i} className="flex items-center justify-between">
                                                    <span className="capitalize">{g.gender || 'Unknown'}</span>
                                                    <div className="flex items-center">
                                                        <div className="w-32 bg-gray-200 rounded-full h-2 mr-2">
                                                            <div 
                                                                className={\`h-2 rounded-full \${g.gender === 'male' ? 'bg-blue-500' : 'bg-pink-500'}\`}
                                                                style={{ width: \`\${(g.count / (stats.totalUsers || 1)) * 100}%\` }}
                                                            ></div>
                                                        </div>
                                                        <span className="text-sm font-medium">{g.count}</span>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>

                                    {/* Age Distribution */}
                                    <div className="bg-white rounded-xl shadow-md p-6">
                                        <h3 className="text-lg font-semibold mb-4">Age Distribution</h3>
                                        <div className="space-y-3">
                                            {(analytics.ageDistribution || []).map((a, i) => (
                                                <div key={i} className="flex items-center justify-between">
                                                    <span>{a.range}</span>
                                                    <div className="flex items-center">
                                                        <div className="w-32 bg-gray-200 rounded-full h-2 mr-2">
                                                            <div 
                                                                className="h-2 rounded-full bg-purple-500"
                                                                style={{ width: \`\${(a.count / (stats.totalUsers || 1)) * 100}%\` }}
                                                            ></div>
                                                        </div>
                                                        <span className="text-sm font-medium">{a.count}</span>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>

                                {/* Top Cities */}
                                <div className="bg-white rounded-xl shadow-md p-6">
                                    <h3 className="text-lg font-semibold mb-4">Top Cities</h3>
                                    <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                                        {(analytics.topCities || []).map((city, i) => (
                                            <div key={i} className="bg-gray-50 rounded-lg p-3 text-center">
                                                <p className="text-sm font-medium text-gray-800">{city.address}</p>
                                                <p className="text-xs text-gray-500">{city.count} users</p>
                                            </div>
                                        ))}
                                    </div>
                                </div>

                                
                                        

                                {/* Analytics Graphs */}
                                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                    {/* Retention Rate Graph */}
                                    {retentionData && (
                                        <RetentionChart data={retentionData} />
                                    )}

                                    {/* DAU Graph */}
                                    {dauData && dauData.dailyData && (
                                        <LineChart 
                                            data={dauData.dailyData} 
                                            label="Daily Active Users" 
                                            color="rgb(59, 130, 246)"
                                            title="Daily Active Users (Last 30 Days)"
                                        />
                                    )}
                                </div>

                                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                    {/* Swipe Activity Graph */}
                                    {swipeData && swipeData.swipeData && (
                                        <LineChart 
                                            data={swipeData.swipeData} 
                                            label="Swipe Count (Likes)" 
                                            color="rgb(236, 72, 153)"
                                            title="Swipe Activity (Last 30 Days)"
                                        />
                                    )}

                                    {/* Profile View Activity Graph */}
                                    {swipeData && swipeData.viewData && (
                                        <LineChart 
                                            data={swipeData.viewData} 
                                            label="Profile Views" 
                                            color="rgb(168, 85, 247)"
                                            title="Profile View Activity (Last 30 Days)"
                                        />
                                    )}
                                </div>
                            </div>
                        )}

                        {activeTab === 'search' && (
                            <div className="space-y-6">
                                <h2 className="text-xl font-bold text-gray-800">Search Users</h2>
                                
                                <div className="bg-white rounded-xl shadow-md p-4">
                                    <div className="flex gap-2 mb-4">
                                        <select 
                                            value={searchType} 
                                            onChange={(e) => setSearchType(e.target.value)}
                                            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 outline-none"
                                        >
                                            <option value="nickname">Nickname</option>
                                            <option value="city">City</option>
                                            <option value="age">Age</option>
                                        </select>
                                        <input
                                            type="text"
                                            value={searchQuery}
                                            onChange={(e) => setSearchQuery(e.target.value)}
                                            placeholder={\`Search by \${searchType}...\`}
                                            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 outline-none"
                                            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                                        />
                                        <button
                                            onClick={handleSearch}
                                            disabled={searchLoading}
                                            className="px-6 py-2 bg-pink-500 text-white rounded-lg hover:bg-pink-600 transition-colors disabled:opacity-50"
                                        >
                                            <i className={\`fas \${searchLoading ? 'fa-spinner fa-spin' : 'fa-search'}\`}></i>
                                        </button>
                                    </div>

                                    {searchResults.length > 0 && (
                                        <div className="overflow-x-auto">
                                            <table className="w-full">
                                                <thead className="bg-gray-50">
                                                    <tr>
                                                        <th className="px-4 py-2 text-left">Nickname</th>
                                                        <th className="px-4 py-2 text-left">Age</th>
                                                        <th className="px-4 py-2 text-left">Gender</th>
                                                        <th className="px-4 py-2 text-left">City</th>
                                                        <th className="px-4 py-2 text-left">Bio</th>
                                                        <th className="px-4 py-2 text-left">Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody className="divide-y divide-gray-100">
                                                    {searchResults.map((user) => (
                                                        <tr key={user.telegram_id}>
                                                            <td className="px-4 py-2 font-medium">{user.nickname}</td>
                                                            <td className="px-4 py-2">{user.age}</td>
                                                            <td className="px-4 py-2 capitalize">{user.gender}</td>
                                                            <td className="px-4 py-2">{user.address}</td>
                                                            <td className="px-4 py-2 text-sm text-gray-500 max-w-xs truncate">{user.bio}</td>
                                                            <td className="px-4 py-2">
                                                                <button
                                                                    onClick={() => handleBanUser(user.telegram_id, 'ban')}
                                                                    className="text-red-500 hover:text-red-700 mr-2"
                                                                    title="Ban User"
                                                                >
                                                                    <i className="fas fa-ban"></i>
                                                                </button>
                                                                <button
                                                                    onClick={() => handleDeleteUser(user.telegram_id)}
                                                                    className="text-red-600 hover:text-red-800"
                                                                    title="Delete User"
                                                                >
                                                                    <i className="fas fa-trash"></i>
                                                                </button>
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                        </div>
                                    )}

                                    {searchResults.length === 0 && searchQuery && !searchLoading && (
                                        <p className="text-center text-gray-500 py-4">No users found</p>
                                    )}
                                </div>
                            </div>
                        )}

                        {activeTab === 'reports' && (
                            <div className="space-y-6">
                                <h2 className="text-xl font-bold text-gray-800">User Reports</h2>
                                
                                {actionMessage && (
                                    <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                                        <p className="text-green-600 text-sm">{actionMessage}</p>
                                    </div>
                                )}

                                {/* Reports List */}
                                <div className="bg-white rounded-xl shadow-md p-6">
                                    <h3 className="text-lg font-semibold mb-4">Reports ({reports.length})</h3>
                                    {reports.length > 0 ? (
                                        <div className="space-y-4">
                                            {reports.map((report) => (
                                                <div key={report.id} className="border border-gray-200 rounded-lg p-4">
                                                    <div className="flex items-start justify-between mb-3">
                                                        <div>
                                                            <span className={\`px-2 py-1 rounded-full text-xs font-medium \${
                                                                report.status === 'pending' ? 'bg-yellow-100 text-yellow-600' :
                                                                report.status === 'reviewed' ? 'bg-blue-100 text-blue-600' :
                                                                report.status === 'resolved' ? 'bg-green-100 text-green-600' :
                                                                'bg-gray-100 text-gray-600'
                                                            }\`}>
                                                                {report.status?.toUpperCase()}
                                                            </span>
                                                            <span className="ml-2 text-sm text-gray-500">
                                                                {new Date(report.created_at).toLocaleString()}
                                                            </span>
                                                        </div>
                                                        <span className="text-sm font-mono text-gray-400">#{report.id}</span>
                                                    </div>
                                                    
                                                    <div className="mb-3">
                                                        <p className="text-sm text-gray-600">
                                                            <span className="font-medium">Reporter:</span> {report.reporter_name || 'Unknown'} (ID: {report.reporter_id})
                                                        </p>
                                                        <p className="text-sm text-gray-600">
                                                            <span className="font-medium">Reported:</span> {report.reported_name || 'Unknown'} (ID: {report.reported_user_id})
                                                        </p>
                                                        <p className="text-sm text-gray-600">
                                                            <span className="font-medium">Reason:</span> 
                                                            <span className={\`ml-1 px-2 py-0.5 rounded text-xs \${
                                                                report.reason === 'fake' ? 'bg-purple-100 text-purple-600' :
                                                                report.reason === 'spam' ? 'bg-orange-100 text-orange-600' :
                                                                'bg-red-100 text-red-600'
                                                            }\`}>
                                                                {report.reason?.toUpperCase()}
                                                            </span>
                                                        </p>
                                                        {report.description && (
                                                            <p className="text-sm text-gray-600 mt-1">
                                                                <span className="font-medium">Description:</span> {report.description}
                                                            </p>
                                                        )}
                                                    </div>

                                                    {report.status === 'pending' && (
                                                        <div className="flex gap-2 mt-3 pt-3 border-t border-gray-100">
                                                            <button
                                                                onClick={() => handleReviewReport(report.id, 'resolved', 'banned')}
                                                                className="px-3 py-1 bg-red-500 text-white rounded text-sm hover:bg-red-600"
                                                            >
                                                                Ban User
                                                            </button>
                                                            <button
                                                                onClick={() => handleReviewReport(report.id, 'resolved', 'shadowbanned')}
                                                                className="px-3 py-1 bg-orange-500 text-white rounded text-sm hover:bg-orange-600"
                                                            >
                                                                Shadowban
                                                            </button>
                                                            <button
                                                                onClick={() => handleReviewReport(report.id, 'dismissed', 'no_action')}
                                                                className="px-3 py-1 bg-gray-500 text-white rounded text-sm hover:bg-gray-600"
                                                            >
                                                                Dismiss
                                                            </button>
                                                        </div>
                                                    )}

                                                    {report.status !== 'pending' && (
                                                        <div className="mt-3 pt-3 border-t border-gray-100">
                                                            <p className="text-sm text-gray-500">
                                                                <span className="font-medium">Action Taken:</span> {report.action_taken || 'None'}
                                                            </p>
                                                        </div>
                                                    )}
                                                </div>
                                            ))}
                                        </div>
                                    ) : (
                                        <p className="text-gray-500 text-center py-4">No reports</p>
                                    )}
                                </div>
                            </div>
                        )}

                        {activeTab === 'moderation' && (
                            <div className="space-y-6">
                                <h2 className="text-xl font-bold text-gray-800">Moderation</h2>
                                
                                {actionMessage && (
                                    <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                                        <p className="text-green-600 text-sm">{actionMessage}</p>
                                    </div>
                                )}

                                {/* Banned Users */}
                                <div className="bg-white rounded-xl shadow-md p-6">
                                    <h3 className="text-lg font-semibold mb-4">Banned Users ({bannedUsers.length})</h3>
                                    {bannedUsers.length > 0 ? (
                                        <div className="overflow-x-auto">
                                            <table className="w-full">
                                                <thead className="bg-gray-50">
                                                    <tr>
                                                        <th className="px-4 py-2 text-left">User ID</th>
                                                        <th className="px-4 py-2 text-left">Nickname</th>
                                                        <th className="px-4 py-2 text-left">Type</th>
                                                        <th className="px-4 py-2 text-left">Reason</th>
                                                        <th className="px-4 py-2 text-left">Banned At</th>
                                                        <th className="px-4 py-2 text-left">Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody className="divide-y divide-gray-100">
                                                    {bannedUsers.map((user) => (
                                                        <tr key={user.telegram_id}>
                                                            <td className="px-4 py-2 font-mono text-sm">{user.telegram_id}</td>
                                                            <td className="px-4 py-2">{user.nickname || 'Unknown'}</td>
                                                            <td className="px-4 py-2">
                                                                <span className={\`px-2 py-1 rounded-full text-xs \${
                                                                    user.is_banned ? 'bg-red-100 text-red-600' : 'bg-orange-100 text-orange-600'
                                                                }\`}>
                                                                    {user.is_banned ? 'Banned' : 'Shadowbanned'}
                                                                </span>
                                                            </td>
                                                            <td className="px-4 py-2 text-sm text-gray-500">{user.ban_reason || 'N/A'}</td>
                                                            <td className="px-4 py-2 text-sm text-gray-500">
                                                                {user.banned_at ? new Date(user.banned_at).toLocaleString() : 'N/A'}
                                                            </td>
                                                            <td className="px-4 py-2">
                                                                <button
                                                                    onClick={() => handleBanUser(user.telegram_id, user.is_banned ? 'unban' : 'unshadowban')}
                                                                    className="px-3 py-1 bg-green-500 text-white rounded text-sm hover:bg-green-600"
                                                                >
                                                                    {user.is_banned ? 'Unban' : 'Unshadowban'}
                                                                </button>
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                        </div>
                                    ) : (
                                        <p className="text-gray-500 text-center py-4">No banned users</p>
                                    )}
                                </div>

                                {/* Quick Stats */}
                                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                                    <div className="bg-white rounded-xl shadow-md p-4">
                                        <p className="text-sm text-gray-500">Total Users</p>
                                        <p className="text-2xl font-bold text-blue-600">{stats.totalUsers}</p>
                                    </div>
                                    <div className="bg-white rounded-xl shadow-md p-4">
                                        <p className="text-sm text-gray-500">Banned Users</p>
                                        <p className="text-2xl font-bold text-red-600">{bannedUsers.filter(u => u.is_banned).length}</p>
                                    </div>
                                    <div className="bg-white rounded-xl shadow-md p-4">
                                        <p className="text-sm text-gray-500">Shadowbanned</p>
                                        <p className="text-2xl font-bold text-orange-600">{bannedUsers.filter(u => u.is_shadowbanned).length}</p>
                                    </div>
                                    <div className="bg-white rounded-xl shadow-md p-4">
                                        <p className="text-sm text-gray-500">Pending Reports</p>
                                        <p className="text-2xl font-bold text-yellow-600">{reports.filter(r => r.status === 'pending').length}</p>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            );
        };

        const root = ReactDOM.createRoot(document.getElementById('root'));
        root.render(<Dashboard />);
    </script>
</body>
</html>`;

// Local development - start bot with polling if not in Vercel environment
if (process.env.NODE_ENV !== 'production' && !process.env.VERCEL) {
    console.log('Starting bot in polling mode for local development...');
    bot.launch().then(() => {
        console.log('Bot started successfully!');
    }).catch((err) => {
        console.error('Failed to start bot:', err);
    });
}